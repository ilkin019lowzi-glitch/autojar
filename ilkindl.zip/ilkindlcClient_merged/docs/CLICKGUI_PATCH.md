# ClickGUI patch (manual edits, yarn names; intermediary in brackets)

Verified from the jar with javap: `ClickGUI` has private `float scrollY`, `float closeAnimation`, `boolean firstOpen`;
methods `init()` [method_25426], `render(...)` [method_25394], `mouseScrolled(...)` [method_25401], `keyPressed(...)` [method_25404].
Not verified (no source): the sign of scrollY, field names of AbstractButton. Check those first.

## 1) Scroll key + reset on reopen   (ClickGUI.java)
```java
// init():  position resets every time the menu opens, modules/settings are untouched
scrollY = 0f;
openAnim = 0f;

// keyPressed(int keyCode, int scanCode, int modifiers): add at the top
if (keyCode == GLFW.GLFW_KEY_PAGE_DOWN || keyCode == GLFW.GLFW_KEY_DOWN) { scrollY -= 24f; return true; }
if (keyCode == GLFW.GLFW_KEY_PAGE_UP   || keyCode == GLFW.GLFW_KEY_UP)   { scrollY += 24f; return true; }
```
If the menu moves the wrong way, swap the signs. Do not let the search bar lose UP/DOWN: put this after the `SearchBar.listening` check.

## 2) Opening animation   (ClickGUI.java)
```java
private float openAnim = 0f;                       // new field

// render(DrawContext context, int mx, int my, float delta): wrap the existing body
openAnim += (1f - openAnim) * 0.14f;
float e = 1f - (float) Math.pow(1f - openAnim, 3);  // ease-out cubic
MatrixStack ms = context.getMatrices();
ms.push();
float cx = mc.getWindow().getScaledWidth() / 2f, cy = mc.getWindow().getScaledHeight() / 2f;
ms.translate(cx, cy, 0); ms.scale(0.92f + 0.08f * e, 0.92f + 0.08f * e, 1f); ms.translate(-cx, -cy, 0);
// ... existing render code ...
ms.pop();
```

## 3) Module card hover glow   (ModuleButton.java, render())
```java
private float glowAnim = 0f;                       // new field
glowAnim += ((isHovered(mouseX, mouseY) ? 1f : 0f) - glowAnim) * 0.18f;   // use the class's own hover test
if (glowAnim > 0.02f)
    Render2DEngine.drawBlurredShadow(context.getMatrices(), x, y, width, height, 10,
        Render2DEngine.applyOpacity(accent, glowAnim * 0.55f));          // draw BEFORE the card background
```

## 4) ilkindlc cursor on the search bar   (SearchBar.java, render())
```java
long win = mc.getWindow().getHandle();
if (isHovered(mouseX, mouseY)) IlkCursor.apply(win); else IlkCursor.reset(win);
```
(The existing `glfwCreateStandardCursor` call in SearchBar can be replaced by this.)
