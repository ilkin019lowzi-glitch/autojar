import thunder.hack.utility.player.CritHover;

public class CritHoverTest {
    static int fail = 0;
    static void check(String n, boolean ok, String i) { System.out.println((ok ? "PASS  " : "FAIL  ") + n + "  " + i); if (!ok) fail++; }
    static boolean inside(double[] p, double[] mn, double[] mx, double m) {
        for (int i = 0; i < 3; i++) if (p[i] < mn[i] + m || p[i] > mx[i] - m) return false; return true; }
    static double[] dir(double yaw, double pitch) {
        double y = Math.toRadians(yaw), p = Math.toRadians(pitch);
        return new double[] { -Math.sin(y) * Math.cos(p), -Math.sin(p), Math.cos(y) * Math.cos(p) }; }
    static double[] angles(double[] eye, double[] to) {
        double dx = to[0]-eye[0], dy = to[1]-eye[1], dz = to[2]-eye[2];
        return new double[] { Math.toDegrees(Math.atan2(-dx, dz)), Math.toDegrees(-Math.atan2(dy, Math.hypot(dx, dz))) }; }
    static double wrap(double a) { a %= 360; if (a > 180) a -= 360; if (a < -180) a += 360; return a; }
    /** ray(eye, look) hitbox'i kesiyor mu (slab) */
    static boolean rayHits(double[] e, double[] d, double[] mn, double[] mx) {
        double t0 = 0, t1 = 100;
        for (int i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1e-9) { if (e[i] < mn[i] || e[i] > mx[i]) return false; continue; }
            double a = (mn[i]-e[i])/d[i], b = (mx[i]-e[i])/d[i];
            if (a > b) { double x = a; a = b; b = x; }
            t0 = Math.max(t0, a); t1 = Math.min(t1, b);
            if (t0 > t1) return false;
        }
        return true;
    }

    public static void main(String[] a) {
        double[] mn = { -0.3, 0.0, -0.3 }, mx = { 0.3, 1.8, 0.3 };
        double[] eye = { 3.0, 1.62, 0.0 };
        CritHover h = new CritHover();
        double[] mid = { 0, 0.9, 0 };
        int n = 800;

        // FAR: asla hitbox icine girmez, hizli hareket eder, donmaz, kilitlenmez
        h.reset();
        double[] prev = null; int inside = 0, frozen = 0; double moved = 0; int distinct = 0; double[] last = null;
        for (int k = 0; k < n; k++) {
            double[] lk = dir(angles(eye, mid)[0], angles(eye, mid)[1]);
            double[] s = h.aim(1, mn, mx, eye, lk, true, 0, false, false, 25);
            if (inside(s, mn, mx, 0)) inside++;
            if (prev != null) { double d = Math.sqrt(Math.pow(s[0]-prev[0],2)+Math.pow(s[1]-prev[1],2)+Math.pow(s[2]-prev[2],2)); moved += d; if (d < 1e-9) frozen++; }
            if (last == null || Math.sqrt(Math.pow(s[0]-last[0],2)+Math.pow(s[1]-last[1],2)+Math.pow(s[2]-last[2],2)) > 0.15) { distinct++; last = s; }
            prev = s;
        }
        check("FAR hep hitbox DISINDA", inside == 0, "icerde=" + inside + "/" + n);
        check("FAR faz", h.getPhase() == CritHover.Phase.FAR, "" + h.getPhase());
        check("FAR hizli (tick basi ort. hareket > 2 cm)", moved / n > 0.02, String.format("ort=%.3f blok/tick", moved / n));
        check("FAR farkli noktalara gidiyor (kilitlenmiyor)", distinct > 40, "farkli nokta=" + distinct);
        check("FAR donmuyor", frozen == 0, "ayni=" + frozen);

        // IDLE: onHit sonrasi 3 tick icinde hitbox disina cikar; hizli; donmaz
        h.reset();
        for (int k = 0; k < 20; k++) h.aim(2, mn, mx, eye, dir(angles(eye, mid)[0], angles(eye, mid)[1]), false, -1, true, false, 25);
        int exitedWithin = -1;
        h.onHit();
        for (int k = 0; k < 6; k++) {
            double[] s = h.aim(2, mn, mx, eye, dir(angles(eye, mid)[0], angles(eye, mid)[1]), false, -1, true, false, 25);
            if (!inside(s, mn, mx, 0) && exitedWithin < 0) exitedWithin = k + 1;
        }
        check("IDLE vurustan sonra 6 tick icinde disari cikar", exitedWithin > 0, "tick=" + exitedWithin);
        prev = null; int out = 0; frozen = 0; moved = 0; distinct = 0; last = null;
        for (int k = 0; k < n; k++) {
            double[] s = h.aim(2, mn, mx, eye, dir(angles(eye, mid)[0], angles(eye, mid)[1]), false, -1, true, false, 25);
            if (!inside(s, mn, mx, 0)) out++;
            if (prev != null) { double d = Math.sqrt(Math.pow(s[0]-prev[0],2)+Math.pow(s[1]-prev[1],2)+Math.pow(s[2]-prev[2],2)); moved += d; if (d < 1e-9) frozen++; }
            if (last == null || Math.sqrt(Math.pow(s[0]-last[0],2)+Math.pow(s[1]-last[1],2)+Math.pow(s[2]-last[2],2)) > 0.12) { distinct++; last = s; }
            prev = s;
        }
        check("IDLE hem icerde hem disarda", out > 100 && out < n - 100, "disarda=" + out + "/" + n);
        check("IDLE hizli", moved / n > 0.015, String.format("ort=%.3f blok/tick", moved / n));
        check("IDLE farkli noktalar", distinct > 60, "farkli nokta=" + distinct);
        check("IDLE donmuyor", frozen == 0, "ayni=" + frozen);

        // VURUS GARANTISI + gecikme jitter'i: Aura donusu tick basi T derece ile sinirli.
        // Hazir olunca attackAllowed() izin verene kadar beklenir; vurus aninda fiili bakis hitbox'i kesmeli.
        for (double T : new double[] { 8, 12, 20, 35 }) {
            h.reset();
            double yaw = angles(eye, mid)[0], pitch = angles(eye, mid)[1];
            int cd = 12, missed = 0, hits = 0, cycles = 150;
            java.util.List<Integer> intervals = new java.util.ArrayList<>();
            int tick = 0, lastHit = -1;
            for (int cyc = 0; cyc < cycles; cyc++) {
                int k = cd;
                while (true) {                       // k = hazir olmasina kalan tick
                    boolean ready = (k <= 0);
                    double[] look = dir(yaw, pitch);
                    double[] s = h.aim(3, mn, mx, eye, look, ready, Math.max(k, 0), true, false, T);
                    double[] ag = angles(eye, s);
                    double dy = wrap(ag[0] - yaw), dp = ag[1] - pitch;
                    double m = Math.hypot(dy, dp);
                    if (m > T) { dy *= T / m; dp *= T / m; }
                    yaw += dy; pitch += dp;
                    tick++; k--;
                    if (h.attackAllowed(ready)) {
                        if (rayHits(eye, dir(yaw, pitch), mn, mx)) hits++; else missed++;
                        if (lastHit >= 0) intervals.add(tick - lastHit);
                        lastHit = tick;
                        break;
                    }
                }
                h.onHit();
            }
            double mean = 0; for (int v : intervals) mean += v; mean /= intervals.size();
            double var = 0; for (int v : intervals) var += (v - mean) * (v - mean); var /= intervals.size();
            double sdMs = Math.sqrt(var) * 50.0;
            check(String.format("VURUS garantisi, donus %.0f deg/tick", T), missed == 0, "tutan=" + hits + " kacan=" + missed);
            if (T == 20) check("VURUS ARALIGI std sapma > 50 ms (TimingConsistency esigi)", sdMs > 50.0, String.format("std=%.1f ms ort=%.1f tick", sdMs, mean));
        }

        // ELYTRA: menzilde hep kenar-ici
        h.reset(); int bad = 0;
        for (int k = 0; k < 200; k++) {
            double[] s = h.aim(4, mn, mx, eye, dir(angles(eye, new double[]{0,1,0.5})[0], angles(eye, new double[]{0,1,0.5})[1]), false, -1, true, true, 25);
            if (!inside(s, mn, mx, 0)) bad++;
        }
        check("ELYTRA menzilde hep icerde", bad == 0, "disarda=" + bad);
        // ELYTRA bakis varyansi: 12 ornekli pencerelerde yaw std sapmasi (LookVectorLock max_variance 2.0 civari)
        h.reset();
        double[] ys = new double[600];
        double yawE = angles(eye, mid)[0], pitchE = angles(eye, mid)[1];
        for (int k = 0; k < ys.length; k++) {
            double[] s2 = h.aim(5, mn, mx, eye, dir(yawE, pitchE), false, -1, true, true, 25);
            double[] ag = angles(eye, s2);
            ys[k] = ag[0];
        }
        double sum = 0; int wins = 0, passW = 0;
        for (int st = 0; st + 12 <= ys.length; st += 12) {
            double m = 0; for (int i = 0; i < 12; i++) m += ys[st + i]; m /= 12;
            double v = 0; for (int i = 0; i < 12; i++) v += (ys[st + i] - m) * (ys[st + i] - m); v /= 12;
            wins++; sum += v; if (v > 0.5) passW++;
        }
        check("ELYTRA bakis kilitlenmiyor (12 ornek penceresinde varyans > 0.5 deg^2)", passW >= wins * 0.9, String.format("ort varyans=%.2f deg^2, gecen pencere=%d/%d", sum / wins, passW, wins));
        check("turnLimit elytra <= 35", h.turnLimit(true, 60) == 35.0 && h.turnLimit(false, 60) == 60.0, "");
        check("ticksToCrit", CritHover.ticksToCrit(0.05, -0.1, 0.2, false) == 2 && CritHover.ticksToCrit(0, 0, 0.2, true) == -1, "");
        System.out.println(fail == 0 ? "\nHEPSI GECTI" : "\nBASARISIZ: " + fail);
        System.exit(fail == 0 ? 0 : 1);
    }
}
