ilkindlcClient_merged  --  ilkindlcClient_patch + ilkindlc_crithover tek pakette.

ilkindlcClient_original/   Orijinal jar icerigi. Mevcut hicbir dosya degistirilmedi.
                           Eklenen 3 yeni .class (Java 21, istemciyle ayni surum):
                             thunder/hack/utility/player/CritHover.class, CritHover$Phase.class
                             thunder/hack/core/packetguard/PacketGuardCore.class
                           Bunlar saf mantik, MC tipi yok. Baglanmadikca hicbir sey yapmazlar.
src/                       Tum kaynaklar tek agacta: ilkindlcWatermarkV3, IlkCursor, CritHover,
                           (+ TriggerBot.java, bkz docs/TRIGGERBOT.md)
                           PacketGuardCore, PacketGuard
test/                      CritHoverTest (18), PacketGuardTest (6): derlendi, hepsi gecti
docs/                      CLICKGUI_PATCH.md, AURA_PATCH.md, PACKETGUARD.md

DURUM
- CritHover + PacketGuardCore: derlendi, testler gecti.
- PacketGuard.java, ilkindlcWatermarkV3.java, IlkCursor.java: DERLENMEDI (Minecraft/yarn jar'lari yok).
- Aura baglantisi (docs/AURA_PATCH.md) ve ClickGUI duzenlemeleri: UYGULANMADI. Aura ve ClickGUI icin
  sadece .class var, kaynak yok. Kaynak projede elle uygulanacak.
- Hicbiri oyunda denenmedi.
