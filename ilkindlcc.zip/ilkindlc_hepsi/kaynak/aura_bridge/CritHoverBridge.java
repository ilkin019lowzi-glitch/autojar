package thunder.hack.utility.player;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_746;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.combat.Aura;

/**
 * Aura <-> CritHover koprusu. Aura.class'a ASM ile eklenen uc cagri buraya gelir:
 *   point(...) : calcRotations icinde nisan noktasi secildikten hemen sonra
 *   gate(...)  : auraLogic'te saldiri karari (shouldAttack) verildikten hemen sonra
 *   hit(...)   : postAttack basinda
 * Hata olursa orijinal davranisa doner (try/catch), oyun cokmez.
 */
public final class CritHoverBridge {
    private static final CritHover H = new CritHover();
    private static boolean warned = false;

    private static boolean on(Aura a) {
        Boolean b = a.critHover.getValue();
        return b != null && b;
    }

    public static class_243 point(Aura a, class_1297 t, class_243 orig, boolean param) {
        try {
            class_746 p = Module.mc.field_1724;
            if (t == null || p == null || !on(a)) return orig;

            class_238 b = t.method_5829();
            double[] min = { b.field_1323, b.field_1322, b.field_1321 };
            double[] max = { b.field_1320, b.field_1325, b.field_1324 };
            class_243 e = p.method_33571();
            double[] eye = { e.field_1352, e.field_1351, e.field_1350 };

            double yr = Math.toRadians(a.rotationYaw), pr = Math.toRadians(a.rotationPitch);
            double[] look = { -Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr) };

            boolean flying = p.method_6128();
            float thr = a.critFallDistance.getValue();
            int ttr = flying ? -1 : CritHover.ticksToCrit(p.field_6017, p.method_18798().field_1351, thr, p.method_24828());
            float cdLeft = a.attackCooldown.getValue() - a.getAttackCooldown();
            int cdT = cdLeft <= 0 ? 0 : (int) Math.ceil(cdLeft / Math.max(a.getAttackCooldownProgressPerTick(), 0.01f));
            int readyIn;
            if (flying) readyIn = cdT;                       // elytra: sadece cooldown belirler
            else if (ttr >= 0) readyIn = Math.max(ttr, cdT); // yerde: dusus + cooldown
            else readyIn = -1;                               // yukseliyor/yerde: bilinmiyor
            boolean ready = a.autoCrit();
            boolean inRange = p.method_5739(t) <= a.getRange();
            double turn = (a.minYawStep.getValue() + a.maxYawStep.getValue()) / 2.0;
            if (flying) turn = H.turnLimit(true, turn);

            double[] r = H.aim(System.identityHashCode(t), min, max, eye, look, ready, readyIn, inRange, flying, turn);
            return new class_243(r[0], r[1], r[2]);
        } catch (Throwable th) {
            warn(th);
            return orig;
        }
    }

    public static boolean gate(Aura a, boolean shouldAttack) {
        try {
            if (!on(a)) return shouldAttack;
            return H.attackAllowed(shouldAttack);
        } catch (Throwable th) {
            warn(th);
            return shouldAttack;
        }
    }

    public static void hit(Aura a) {
        try {
            if (on(a)) H.onHit();
        } catch (Throwable th) {
            warn(th);
        }
    }

    private static void warn(Throwable th) {
        if (!warned) { warned = true; System.err.println("[CritHover] hata, orijinal davranisa donuldu: " + th); }
    }
}
