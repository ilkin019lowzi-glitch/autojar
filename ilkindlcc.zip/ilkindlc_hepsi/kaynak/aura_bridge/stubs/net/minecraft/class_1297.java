package net.minecraft;
public class class_1297 {
  public float field_6017; public class_238 box = new class_238(); public class_243 eye = new class_243(0,0,0); public class_243 vel = new class_243(0,0,0);
  public boolean ground; public float dist;
  public class_238 method_5829(){return box;} public class_243 method_33571(){return eye;} public class_243 method_18798(){return vel;}
  public boolean method_24828(){return ground;} public float method_5739(class_1297 o){return dist;}
}
