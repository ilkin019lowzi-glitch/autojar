package net.minecraft;
public class class_238 { public double field_1323, field_1322, field_1321, field_1320, field_1325, field_1324; }
