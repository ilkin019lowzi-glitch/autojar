package net.minecraft;
public class class_310 { public class_746 field_1724 = new class_746(); }
