package thunder.hack.features.modules;
public abstract class Module { public static final net.minecraft.class_310 mc = new net.minecraft.class_310(); }
