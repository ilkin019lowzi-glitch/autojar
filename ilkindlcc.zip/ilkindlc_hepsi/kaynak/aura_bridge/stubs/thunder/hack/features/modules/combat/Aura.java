package thunder.hack.features.modules.combat;
import net.minecraft.class_1297; import thunder.hack.setting.Setting;
public class Aura extends thunder.hack.features.modules.Module {
  public static class_1297 target; public float rotationYaw, rotationPitch;
  public final Setting<Boolean> critHover = new Setting<>("CritHover", true);
  public final Setting<Float> critFallDistance = new Setting<>("c", 0.2f), attackCooldown = new Setting<>("a", 0.9f);
  public final Setting<Integer> minYawStep = new Setting<>("min", 20), maxYawStep = new Setting<>("max", 40);
  public boolean crit; public float range = 3.0f, cd = 1f, cdPerTick = 0.05f;
  public boolean autoCrit(){return crit;} public float getRange(){return range;}
  public float getAttackCooldown(){return cd;} public float getAttackCooldownProgressPerTick(){return cdPerTick;}
}
