package thunder.hack.setting;
public class Setting<T> { public T v; public Setting(String n, T d){v=d;} public T getValue(){return v;} }
