import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;
import java.nio.file.*;

public class Patch {
  static final String BR = "thunder/hack/utility/player/CritHoverBridge";
  static final String ENT = "net/minecraft/class_1297", VEC = "net/minecraft/class_243";
  static final String SET = "thunder/hack/setting/Setting";

  static AbstractInsnNode nextReal(AbstractInsnNode n) { n = n.getNext(); while (n != null && n.getOpcode() < 0) n = n.getNext(); return n; }
  static MethodNode method(ClassNode cn, String name, String desc) {
    for (MethodNode m : cn.methods) if (m.name.equals(name) && m.desc.equals(desc)) return m;
    throw new RuntimeException("metot yok: " + name + desc);
  }

  public static void main(String[] a) throws Exception {
    byte[] in = Files.readAllBytes(Path.of(a[0]));
    ClassNode cn = new ClassNode();
    new ClassReader(in).accept(cn, 0);
    String AURA = cn.name;

    // (a) autoCrit ve getRange private -> public (kopru cagirabilsin)
    for (MethodNode m : cn.methods)
      if ((m.name.equals("autoCrit") && m.desc.equals("()Z")) || (m.name.equals("getRange") && m.desc.equals("()F")))
        m.access = (m.access & ~Opcodes.ACC_PRIVATE) | Opcodes.ACC_PUBLIC;

    // (b) public final Setting<Boolean> critHover + ctor sonunda olustur
    for (FieldNode f : cn.fields) if (f.name.equals("critHover")) throw new RuntimeException("zaten yamali");
    cn.fields.add(new FieldNode(Opcodes.ACC_PUBLIC | Opcodes.ACC_FINAL, "critHover", "L" + SET + ";", "L" + SET + "<Ljava/lang/Boolean;>;", null));
    MethodNode init = null;
    for (MethodNode m : cn.methods) if (m.name.equals("<init>")) { if (init != null) throw new RuntimeException("birden fazla ctor"); init = m; }
    AbstractInsnNode ret = null; int rets = 0;
    for (AbstractInsnNode n = init.instructions.getFirst(); n != null; n = n.getNext()) if (n.getOpcode() == Opcodes.RETURN) { ret = n; rets++; }
    if (rets != 1) throw new RuntimeException("ctor RETURN sayisi " + rets);
    InsnList il = new InsnList();
    il.add(new VarInsnNode(Opcodes.ALOAD, 0));
    il.add(new TypeInsnNode(Opcodes.NEW, SET));
    il.add(new InsnNode(Opcodes.DUP));
    il.add(new LdcInsnNode("CritHover"));
    il.add(new InsnNode(Opcodes.ICONST_1));
    il.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/Boolean", "valueOf", "(Z)Ljava/lang/Boolean;", false));
    il.add(new MethodInsnNode(Opcodes.INVOKESPECIAL, SET, "<init>", "(Ljava/lang/String;Ljava/lang/Object;)V", false));
    il.add(new FieldInsnNode(Opcodes.PUTFIELD, AURA, "critHover", "L" + SET + ";"));
    init.instructions.insertBefore(ret, il);

    // (c) calcRotations: nisan noktasi secildikten hemen sonra
    MethodNode cr = method(cn, "calcRotations", "(Z)V");
    int c = 0;
    for (AbstractInsnNode n = cr.instructions.getFirst(); n != null; n = n.getNext()) {
      if (n instanceof MethodInsnNode mi && mi.name.equals("getLegitLook") && mi.owner.equals(AURA)) {
        AbstractInsnNode st = nextReal(n);
        if (!(st instanceof VarInsnNode v && v.getOpcode() == Opcodes.ASTORE && v.var == 2)) throw new RuntimeException("getLegitLook sonrasi astore_2 degil");
        AbstractInsnNode al = nextReal(st);
        if (!(al instanceof VarInsnNode v2 && v2.getOpcode() == Opcodes.ALOAD && v2.var == 2)) throw new RuntimeException("astore_2 sonrasi aload_2 degil");
        InsnList p = new InsnList();
        p.add(new VarInsnNode(Opcodes.ALOAD, 0));
        p.add(new FieldInsnNode(Opcodes.GETSTATIC, AURA, "target", "L" + ENT + ";"));
        p.add(new VarInsnNode(Opcodes.ALOAD, 2));
        p.add(new VarInsnNode(Opcodes.ILOAD, 1));
        p.add(new MethodInsnNode(Opcodes.INVOKESTATIC, BR, "point", "(L" + AURA + ";L" + ENT + ";L" + VEC + ";Z)L" + VEC + ";", false));
        p.add(new VarInsnNode(Opcodes.ASTORE, 2));
        cr.instructions.insertBefore(al, p);
        c++; break;
      }
    }
    if (c != 1) throw new RuntimeException("calcRotations hook bulunamadi");

    // (d) auraLogic: iload_3 ifeq ... aload_0 iconst_0 invokevirtual shieldBreaker  oncesine gate
    MethodNode al = method(cn, "auraLogic", "()V");
    int g = 0;
    for (AbstractInsnNode n = al.instructions.getFirst(); n != null; n = n.getNext()) {
      if (n.getOpcode() == Opcodes.ILOAD && ((VarInsnNode) n).var == 3) {
        AbstractInsnNode b = nextReal(n);
        if (b == null || b.getOpcode() != Opcodes.IFEQ) continue;
        AbstractInsnNode c1 = nextReal(b), c2 = c1 == null ? null : nextReal(c1), c3 = c2 == null ? null : nextReal(c2);
        if (c1 != null && c1.getOpcode() == Opcodes.ALOAD && c2 != null && c2.getOpcode() == Opcodes.ICONST_0
            && c3 instanceof MethodInsnNode mi && mi.name.equals("shieldBreaker")) {
          InsnList p = new InsnList();
          p.add(new VarInsnNode(Opcodes.ALOAD, 0));
          p.add(new VarInsnNode(Opcodes.ILOAD, 3));
          p.add(new MethodInsnNode(Opcodes.INVOKESTATIC, BR, "gate", "(L" + AURA + ";Z)Z", false));
          p.add(new VarInsnNode(Opcodes.ISTORE, 3));
          al.instructions.insertBefore(n, p);
          g++; break;
        }
      }
    }
    if (g != 1) throw new RuntimeException("auraLogic gate noktasi bulunamadi");

    // (e) postAttack(ZZ)V basi
    MethodNode pa = method(cn, "postAttack", "(ZZ)V");
    InsnList h = new InsnList();
    h.add(new VarInsnNode(Opcodes.ALOAD, 0));
    h.add(new MethodInsnNode(Opcodes.INVOKESTATIC, BR, "hit", "(L" + AURA + ";)V", false));
    pa.instructions.insert(h);

    // dogrulama: yamali metotlarda yigin/yerel tutarliligi (sinif yuklemeden)
    for (MethodNode m : new MethodNode[] { init, cr, al, pa }) {
      Analyzer<BasicValue> an = new Analyzer<>(new BasicVerifier());
      an.analyze(cn.name, m);
    }

    ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
    cn.accept(cw);
    Files.write(Path.of(a[1]), cw.toByteArray());
    System.out.println("YAMA TAMAM: ctor+calcRotations+auraLogic+postAttack, BasicVerifier gecti");
  }
}
