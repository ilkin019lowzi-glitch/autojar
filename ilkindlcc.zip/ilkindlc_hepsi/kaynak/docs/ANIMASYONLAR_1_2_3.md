ILKINDLC - ANIMASYONLAR 1 / 2 / 3
=================================

Bu yama su uc animasyonun kaynaklarini ekler:
1) ClickGUI acilisinda merkezden yumusak buyume (260 ms cubic ease-out).
2) Loading overlay: koyu arkaplan, cyan/mor donen noktalar, ILKINDLC yazisi ve kayan vurgu.
3) Module toggle: animasyonlu anahtar ve aktif satir icin hafif cyan vurgu.

DOSYALAR
- src/thunder/hack/gui/clickui/IlkAnimations.java
- src/thunder/hack/gui/clickui/IlkLoadingAnimation.java (guncellendi)
- src/thunder/hack/gui/clickui/IlkMenu.java (onInit animasyon zamanlayicisini baslatir)

ENTEGRASYON NOTU
Bu arsivde ClickGUI'nin asil render sinifi ve ModuleButton kaynaklari bulunmadigindan,
1 ve 3 numarali animasyonlarin tum kategori/modul cizimlerine uygulanmasi icin asagidaki
iki kucuk cagri asil kaynakta eklenmelidir.

A) ClickGUI render metodunda kategori/pencere cizim blogunu sar:

    MatrixStack matrices = context.getMatrices();
    IlkAnimations.beginAnimatedContent(matrices,
        mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());
    try {
        // mevcut kategori / pencere render dongusu BURADA kalir
    } finally {
        IlkAnimations.endAnimatedContent(matrices);
    }

B) ModuleButton'in render metodunda, modul adi ve toggle cizilirken:

    IlkAnimations.renderModuleGlow(context, x, y, width, height, module.isEnabled());
    IlkAnimations.renderModuleToggle(context, module.getName(), toggleX, toggleY,
        module.isEnabled());

C) Config yukleme isleminin ekranda gosterildigi render frame'inde:

    IlkLoadingAnimation.render(context, scaledWidth, scaledHeight,
        System.currentTimeMillis(), "Config yukleniyor...");

Mevcut kaynak arsivinde A ve B icin asil siniflar olmadigindan bu cagri noktalarini
kendiliginden eklemek mumkun degildi. Yardimci siniflar projedeki bilinen DrawContext,
MatrixStack, FontRenderers ve Render2DEngine API'lerini kullanir. Tam proje uzerinde
Minecraft/Yarn bagimliliklariyla derleme ve oyun ici test yapilmadi.
