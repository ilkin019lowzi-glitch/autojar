ILKINDLC - ANIMASYONLAR 1 / 2 / 3 / 9
=====================================

Mevcut animasyon kaynaklari:
1) ClickGUI merkezden yumusak buyume.
2) Cyan/mor loading overlay.
3) Module toggle ve aktif satir vurgusu.
9) Cursor Trail: fare hareket ettikce kisa omurlu cyan/mor parcacik izi.

9 NUMARALI ANIMASYON DOSYASI
- src/thunder/hack/gui/clickui/IlkCursorTrail.java

CLICKGUI RENDER ENTEGRASYONU
ClickGUI'nin ana render metodunda, mouseX/mouseY degerleri GUI olcekli koordinatlardaysa:

    long now = System.currentTimeMillis();
    IlkCursorTrail.update(mouseX, mouseY, now);
    IlkCursorTrail.render(context, now);

Bu iki cagrinin, ClickGUI arka plani ve paneller cizildikten sonra; imlecin ustune
cizilmesi isteniyorsa vanilla/custom cursor ciziminden hemen once yapilmasi onerilir.
ClickGUI kapanirken IlkCursorTrail.clear() cagrilabilir.

NOTLAR
Bu arsivde ClickGUI'nin asil render sinifi bulunmadigindan cagrilar otomatik olarak
render dongusune yerlestirilemedi. Yardimci sinif ve entegrasyon talimati eklendi.
Tam Fabric/Yarn proje ortami olmadan derleme ve oyun ici test yapilmadi.
