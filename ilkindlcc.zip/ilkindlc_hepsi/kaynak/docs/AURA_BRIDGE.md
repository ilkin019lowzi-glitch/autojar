# Aura'ya baglanan CritHover (jar: ilkindlcClient_crithover.jar)

DURUM: Aura.class'a ASM ile yama atildi (javap farki + ASM BasicVerifier ile dogrulandi). CritHover 30+ kontrolle, kopru sahte MC
siniflariyla 14 senaryoda test edildi. OYUNDA DENENMEDI. Orijinal jar'i yedekte tut.

## Aura.class degisiklikleri (kisa, dogrusal eklemeler)
1. `CritHover` ayari (public final Setting<Boolean>, varsayilan ACIK). Kapatinca Aura eskisi gibi.
2. calcRotations: nisan noktasi secildikten sonra `CritHoverBridge.point(...)` (Interact / Track / Grim; Netpot ve HvH baglanmadi).
3. auraLogic: `shouldAttack = CritHoverBridge.gate(this, shouldAttack)` (hazir olduktan sonra 0-4 tick rastgele bekleme).
4. postAttack basi: `CritHoverBridge.hit(this)` (yeni kenar payi, imleci disari cikar).
5. autoCrit() ve getRange() private -> public.
Kopru try/catch icinde, hata olursa orijinal davranis.

## Elytra davranisi
- Menzil disi: hitbox'in 1-2 cm DISINA kilitli, hedefi takip eder (test: 1-2 cm disinda, tick basi sicrama = hedefin hizi).
- Menzilde, cooldown dolmadi: yine disarida. Dolmaya yaklasinca (donus hizi hesaba katilir) iceri, kenardan 1-2 cm.
- Her vurustan sonra ilk tick'te disari. 10/20/35 deg/tick donus hizlarinda 120/120 vurus tuttu (simulasyon).

## Riskler
- Oyunda test edilmedi. Kopru Minecraft intermediary adlarini kullanir (class_1297...), dev ortaminda (yarn) calismaz.
- auraLogic tick basina birden fazla cagriliyorsa bekleme sayaci kisalir.
- Elytra icin "hazir olmasina kalan tick" cooldown ayarindan hesaplanir (attackCooldown / getAttackCooldown).
  Aura elytra'da baska bir kosulla saldiriyorsa iceri donus gec kalabilir.

## Yeniden uretme
aura_bridge/tools/Patch.java yamayi orijinal Aura.class'a uygular (JDK icindeki ASM, --add-exports bayraklariyla).
Koprunun derlenmesi icin aura_bridge/stubs ile birlikte derlenir; jar'a yalniz CritHoverBridge ve CritHover siniflari girer.
