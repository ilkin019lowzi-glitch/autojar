# Aura + CritHover entegrasyonu (yarn adlari)

Durum: `CritHover.java` v3 derlendi ve `test/CritHoverTest.java` ile 18 kontrol 6 ardisik calistirmada gecti (saf matematik, vurus-garantisi simulasyonu dahil).
Aura'ya baglama kismi DERLENMEDI, oyunda DENENMEDI: Aura icin sadece .class var, kaynak yok.
Hook yerleri javap ile bytecode'dan bulundu.

## Bytecode'dan dogrulananlar
- `autoCrit()` private boolean: kritik + cooldown hazir mi. `critFallDistance` / `shouldRandomizeFallDistance()` ile fallDistance esigi.
- `calcRotations(boolean)`: nisan noktasi su ternary ile seciliyor:
  `elytra ? target.getEyePos() : getLegitLook(target)` (ofset ~155-184). Sonra `Managers.PLAYER.checkRtx(rotationYaw, rotationPitch, ...)` ve yaw/pitch step sinirlayicisi gelir.
- `getLegitLook` sadece `calcRotations`'tan cagriliyor. `calcNetpotRotations` ve `calcHvHRotations` kendi noktasini hesapliyor, onlara hook YOK.
- Saldiri kapisi: `autoCrit()` + `lookingAtHitbox` (checkRtx sonucu). Nokta hitbox icindeyse kapi acilir.
- `rotationYaw` / `rotationPitch` public alanlar = Aura'nin mevcut nisani.

## 1) Alan + ayarlar (Aura.java)
```java
private final CritHover critHover = new CritHover();

// Setting ctor'unu kendi projene gore uyarla (dogrulayamadim)
public final Setting<Boolean> critHoverOn = new Setting<>("CritHover", true);
public final Setting<Float> hoverEdgeMin = new Setting<>("EdgeMinCm", 1.0f, 0.2f, 3f);
public final Setting<Float> hoverEdgeMax = new Setting<>("EdgeMaxCm", 2.0f, 0.5f, 5f);
public final Setting<Float> hoverIdleOut = new Setting<>("IdleOutCm", 10f, 0f, 30f);
public final Setting<Integer> hoverLead = new Setting<>("LeadTicks", 2, 0, 5);
```

## 2) Nisan noktasi (calcRotations icinde, yukaridaki ternary'nin hemen altina)
```java
Vec3d vec = flying ? target.getEyePos() : getLegitLook(target);   // mevcut satir
if (critHoverOn.getValue()) vec = critHoverPoint(target, flying); // YENI
```

```java
private Vec3d critHoverPoint(Entity t, boolean flying) {
    critHover.edgeMin = hoverEdgeMin.getValue() / 100.0;
    critHover.edgeMax = hoverEdgeMax.getValue() / 100.0;
    critHover.idleOut = hoverIdleOut.getValue() / 100.0;
    critHover.leadTicks = hoverLead.getValue();

    Box b = t.getBoundingBox();
    Vec3d e = mc.player.getEyePos();

    // Aura'nin kendi nisani (client kamerasi degil)
    double yr = Math.toRadians(rotationYaw), pr = Math.toRadians(rotationPitch);
    double[] look = { -Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr) };

    float thr = critFallDistance.getValue();   // rastgele esik aciksa (shouldRandomizeFallDistance) yaklasik kalir
    int ttr = CritHover.ticksToCrit(mc.player.fallDistance, mc.player.getVelocity().y, thr, mc.player.isOnGround());

    // Hazir olmasina kalan tick: kritik (dusus) ve cooldown'dan buyugu. Bilinmiyorsa -1.
    // Cooldown icin: getAttackCooldown() 0..1 ilerleme, getAttackCooldownProgressPerTick() tick basi artis (ikisi de Aura'da var, dogrulanmadi)
    float cdLeft = attackCooldown.getValue() - getAttackCooldown();
    int cdTicks = cdLeft <= 0 ? 0 : (int) Math.ceil(cdLeft / Math.max(getAttackCooldownProgressPerTick(), 0.01f));
    int ready_in = (ttr < 0) ? -1 : Math.max(ttr, cdTicks);

    boolean ready = autoCrit();
    boolean inRange = mc.player.distanceTo(t) <= getRange();
    double turn = (minYawStep.getValue() + maxYawStep.getValue()) / 2.0;   // Aura'nin gercek donus hizi (derece/tick)

    double[] r = critHover.aim(t.getId(),
        new double[]{b.minX, b.minY, b.minZ}, new double[]{b.maxX, b.maxY, b.maxZ},
        new double[]{e.x, e.y, e.z}, look, ready, ready_in, inRange, flying, turn);
    return new Vec3d(r[0], r[1], r[2]);
}
```

## 3) Her vurustan sonra (attack() ya da postAttack() sonu)
```java
critHover.onHit();      // sonraki vurus icin yeni 1-2 cm kenar payi
```
`onDisable()` ve hedef degisiminde `critHover.reset()` (hedef degisimini sinif zaten id'den anliyor).

## v2 davranisi
- FAR (menzil disi): imlec hep hitbox disinda, hizli hizli rastgele noktalara gider.
- IDLE (menzilde, hazir degil): `onHit()` sonrasi 2 tick icinde disari cikar, sonra hizli rastgele gezer, durmaz.
- STRIKE gecisi donus hizina gore hesaplanir: acisal uzaklik / turnPerTick + leadTicks. Simulasyonda 8-35 deg/tick'te 120/120 vurus tuttu.
- Garanti, `ready_in` dogruysa gecerli. Yere basarken/yukselirken kritik tahmini yok (-1); o durumda sadece hazir olunca doner,
  yavas donus hizinda (<10 deg/tick) kacirabilir. Bu yuzden cooldown'i da `ready_in`'e kattim.

## v3: kendi sunucundaki anti-cheat testi icin profil
Kaynak: `AntiElytraTarget` en_config.yml esikleri. Kontrollerin ic mantigini gormedim (jar obfuscate), sadece config adi + esige gore tahmin ettim.
Gercek sonuc sunucuda `/aet log` ile gorulur. Tablo:

| Kontrol (esik) | CritHover'daki karsiligi |
|---|---|
| TimingConsistency (std < 50 ms) | `attackAllowed()`: hazir olduktan sonra 0-4 tick rastgele bekleme. Testte vurus araligi std ~70 ms |
| ElytraCombatRate (max_rot_per_tick 40) | `turnLimit(elytra, auraTurn)` elytra'da <= 35 derece/tick |
| LookVectorLock (varyans < 2.0) / PitchLock | elytra STRIKE'ta kutu icinde +-16 cm gezinme. Testte 12 ornekte ort. yaw varyansi ~5-6 |
| RotationConsistency / SmoothAim (std dusuk) | easing + %25 overshoot, hedef basina farkli hiz |
| AimSnap (ani sicrama) | gezinme tick basina sinirli, FAR/IDLE'da lerp <= 0.8 |
| AttackRate (12/sn) | kritik cooldown zaten ~1-2/sn |
| UseItemRotationMismatch, FireworkPattern, IncapableSwap, PacketOrderE | ElytraHelper tarafi, CritHover etkilemez. Asagidaki ElytraHelper notuna bak |

## 4) Saldiri kapisi (auraLogic icinde, `autoCrit()` ile `lookingAtHitbox` kontrolunun yaninda)
```java
// mevcut: if (autoCrit() && (lookingAtHitbox || skipRayTraceCheck())) -> attack
// yeni:   && critHover.attackAllowed(autoCrit())
```
`attackAllowed` her tick cagrilmali (sayac tutar). Menzil disinda ya da hazir degilken false doner.

## 5) Netpot ve HvH hook'lari
- **Netpot** (`calcNetpotRotations`): nisan noktasi `target` konumu + hiz tahmini + `NetpotNoiseAngle` gurultusu ile kuruluyor
  (hedef Y'si `getEyeHeight` kadar). Gurultu `.add(dx,dy,dz)` ile eklendikten hemen sonra (bytecode ofseti ~448) Vec3d'yi
  `critHoverPoint(target, flying)` ile degistir. `NetpotAimOffsetX/Y/Z` alanlari yalnizca `onEnable`'da set ediliyor, hesapta kullanilmiyor.
- **HvH** (`calcHvHRotations`): `target.getEyePos()` ile bounding box'tan kurulan Vec3d'leri kullaniyor (ofset ~46-187). Ayni sekilde
  son nisan Vec3d'sini `critHoverPoint` ile degistir.
Ikisi de kaynaksiz oldugu icin satir numarasi degil, "nisan Vec3d'si hesaplandiktan sonra" noktasi. Derlenmedi.

## ElytraHelper (dogrulanmadi)
Sinifta `tryAuraAttackOnFirework()`, `lastElytraAttackTime`, `swapping`, `hasUsedFirework`, `overshoot`, `predict*` var. Kaynak yok, o yuzden degistirmedim.
Aura firework aninda saldiriyorsa o cagriyi da `critHover.attackAllowed(true)` ile gecir ki iki sistem ayni ritmi uretmesin.

## Dikkat
- `autoCrit()` icinde `shouldRandomizeFallDistance()` her cagrida yeni rastgele esik cekiyor. Burada bir kez daha cagirmak
  esigi biraz oynatir. Sorun degil ama istersen `autoCrit()` sonucunu tick basina bir alana yazip onu kullan.
- `ready` hook'u `calcRotations`'in aldigi boolean ile ayni anlama gelmeyebilir; bu yuzden `autoCrit()` dogrudan cagrildi.
- Netpot ve HvH modlarinda sistem calismaz. Onlara baglamak icin ikisinin nisan noktasini hesapladigi yeri gormem lazim.
- Donus hizini Aura'nin min/maxYawStep ayarlari belirliyor. Cok dusukse IDLE'dan STRIKE'a donus gec kalir. LeadTicks'i 3-4 yap.
- Vurus noktasi hitbox icinde oldugu icin `lookingAtHitbox` kapisi acik kalir. Sunucu tarafi dogrulamasi (Grim vb.) icin
  `grimRayTrace` ayari aciksa nokta mutlaka kutunun icinde kaliyor; ek ayar gerekmiyor.
