# ilkindlc Configs + Main menu entegrasyonu

## Neler eklendi
- ClickGUI'nin (P ile açılan ekran) sağ üstüne `CONFIGS` ve `MAIN` düğmeleri eklendi.
- `CONFIGS`, istemcide zaten bulunan `ThunderGui` ekranını doğrudan `CfgManager` modunda açar.
- `MAIN`, Minecraft ana menüsüne döner.

## Config sistemi
Bu istemcinin JAR'ında `ConfigManager`, `ConfigWindow` ve `ThunderGui` config yöneticisi zaten mevcut.
Config yöneticisi:
1. `getConfigList()` ile `.th` dosyalarını listeler.
2. `save(name)` ile tüm modül ayarlarını dosyaya yazar.
3. `load(name)` ile seçilen config'i yükler.
4. `delete(name)` ile config'i siler.

Dosyalar: `.minecraft/ilkindlc/configs/<isim>.th`

## Önemli derleme notu
Bu pakette `IlkMenu.java` kaynak kodu güncellendi; ancak mevcut `ilkindlcClient_crithover.jar`
yeniden derlenmedi. JAR, Minecraft/Yarn geliştirme bağımlılıkları bu arşivde bulunmadığı için
burada güvenli biçimde yeniden derlenemedi. Değişikliğin oyunda görünmesi için projeyi kendi
Fabric/Yarn build ortamında derleyip yeni `IlkMenu.class` dosyasını JAR'a eklemelisin.

## Kendi config örneğin
Kendi `.th` config dosyanı gönderirsen yapısını inceleyip modül/ayar uyumluluğunu kontrol edebilirim.
