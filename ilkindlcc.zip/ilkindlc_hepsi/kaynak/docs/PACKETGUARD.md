# PacketGuard (Grim BadPackets A / F / G)

Durum: `PacketGuardCore` derlendi, `test/PacketGuardTest.java` 6/6 gecti (Grim A/F/G mantigini taklit eden simulasyonla).
`PacketGuard.java` (Minecraft'a baglanan ince kisim) DERLENMEDI, oyunda DENENMEDI.

## Grim'den dogrulananlar (jar'daki bytecode)
- BadPacketsA: HELD_ITEM_CHANGE, slot == lastSlot -> bayrak ("Sent duplicate slot id")
- BadPacketsF: START_SPRINTING iken lastSprinting == true veya STOP_SPRINTING iken false -> bayrak ("duplicate sprinting status")
- BadPacketsG: ayni mantik, sneak icin ("duplicate sneaking status")
- Grim durumu yalniz kendisine ulasan paketlerden gunceller. Guard da yalniz gercekten gonderilenlerle ilerler.

## Aura'da bulunan kaynak (ilkindlcClient_original, bytecode)
- `Aura.disableSprint()`: `setSprinting(false)` + `sprintKey.setPressed(false)` + elle `ClientCommandC2SPacket(STOP_SPRINTING)`.
- `Aura.enableSprint()`: ayni sekilde elle `START_SPRINTING`.
- Vanilla da `sendSprintingPacket` ile kendi paketini yollar. Ikisi ust uste binince ayni durum iki kez gider -> BadPacketsF.
- `Core.onPacketSend` yalniz `serverSprint` alanini tutuyor ve `lockSprint` varsa iptal ediyor. Tekrar engelleyen bir sey yok.
- `preAttack`'taki RELEASE_USE_ITEM (BlockPos.ORIGIN, Direction.DOWN) vanilla ile ayni, sorun degil.

## Kurulum
1. `src/thunder/hack/core/packetguard/` altindaki iki dosyayi projeye ekle.
2. `ThunderHack.onInitialize()` icinde, `EVENT_BUS` olustuktan sonra: `EVENT_BUS.subscribe(new PacketGuard());`
3. Baska bir ayar gerekmiyor. Aura kapaliyken de calisir (vanilla/baska modul tekrarlarini da keser).

## Dikkat (dogrulanmadi)
- Yarn sinif adlari surumune gore degisebilir (ClientCommandC2SPacket, UpdateSelectedSlotC2SPacket, UpdateSelectedSlotS2CPacket, GameJoinS2CPacket, PlayerRespawnS2CPacket).
- `PacketEvent.Send.cancel()` ile paketin gercekten dusmesi, ilgili mixin'in `isCancelled()`'a bakmasina bagli. Core zaten `lockSprint` icin ayni yolu kullaniyor, buyuk ihtimalle calisir.
- `Module.sendPacketSilent` olayi atliyor olabilir. Bunu kullanan kod varsa guard onlari gormez ve durum kayabilir.
- Sunucu slot'u zorla degistirince (S2C) guard bir sonraki slot paketini mutlaka geciriyor, yani desync olmaz. Grim o paketi yine tekrar sayarsa bu Grim'in kendi davranisi.

## Kapsam disi
Hangi BadPackets loglari dustugunu yazmadin. A, F, G bu analizle kapandi. Baska harfler (ornegin H, U, Y, P, Z) gorursen log satirini at, ona bakarim.
Aura'nin Grim modunda gonderdigi ekstra `PlayerMoveC2SPacket.Full` paketlerinin Grim'in hangi kontrolunu tetikleyebilecegini incelemedim.
