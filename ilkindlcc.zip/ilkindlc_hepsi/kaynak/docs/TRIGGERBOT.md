# TriggerBot
Crosshair hitbox'in uzerindeyken otomatik vurur. Dosya: src/thunder/hack/features/modules/combat/TriggerBot.java
- OnlyCrit (varsayilan acik): vanilla kritik kosulu saglanana ve cooldown hazir olana kadar bekler. Kosarken kritik olmaz; bu yuzden kosuyorsan vurmaz.
- Cooldown (0.5-1.0, varsayilan 0.95), Players, Mobs, IgnoreFriends, PauseWhenUsing.
- Nisani degistirmez, sadece oyuncunun kendi bakisini kullanir. Paket/rotasyon manipulasyonu yok.
Kurulum: ModuleManager'da ilkindlcWatermarkV2 gibi kayitli modul listesine `new TriggerBot()` ekle (kaynak yok, elle).
Durum: DERLENMEDI, oyunda DENENMEDI. Kullanilan API'ler javap ile jar'daki Module/Setting/FriendManager imzalarina karsi kontrol edildi.
