# Ses olaylari entegrasyonu

`resources/assets/minecraft/sounds.json` ve dort OGG dosyasi mevcut. `thunder.hack.utility.sound.IlkSound` ses oynatma yardimcisini ekler.

Olay noktalarinda su metotlari cagir:

- Ilk istemci acilisi / ilk kullanilabilir ekran: `IlkSound.welcomeOnce()`
- Config diske basariyla yazildiktan sonra: `IlkSound.configCreated()`
- Config basariyla yuklendikten sonra: `IlkSound.configSelected()`
- Kill kesinlestiginde (yalnizca bir kez): `IlkSound.confirmedKill()`

Onemli: Bu ZIP'teki kaynaklar arasinda istemci yasam dongusu, ConfigManager'in save/load metotlari ve kill event sinifi bulunmuyor. Bu nedenle bu dort cagriyi gercek olay noktalarina otomatik yerlestirmek, mevcut kaynakla mumkun degil. Yardimci sinif ve ses kaynaklari hazir; cagri noktalarini tam kaynak projende eklemelisin. `IlkLoadingAnimation.render(...)` da config yukleme ekraninin render dongusunden cagrilmali ve yukleme bitince cagrilmamali.

Bu yama derlenmedi veya oyun icinde test edilmedi. `PositionedSoundInstance.master(Identifier, float)` imzasini kullandigi icin hedef Minecraft/Yarn surumunde API uyumunu derlerken kontrol et.
