package thunder.hack.core.packetguard;

import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket;
import thunder.hack.events.impl.PacketEvent;

/**
 * Giden paketleri suzer. Yeni bir modul degil, tek bir dinleyici.
 * Kayit (ThunderHack.onInitialize icinde, EVENT_BUS olusturulduktan sonra):
 *     ThunderHack.EVENT_BUS.subscribe(new PacketGuard());
 *
 * DERLENMEDI. Yarn adlari: ClientCommandC2SPacket (class_2848), UpdateSelectedSlotC2SPacket (class_2868),
 * UpdateSelectedSlotS2CPacket (class_2735), GameJoinS2CPacket, PlayerRespawnS2CPacket. Surume gore dogrula.
 */
public class PacketGuard {
    public final PacketGuardCore core = new PacketGuardCore();

    // LOWEST: baska dinleyiciler (Core.lockSprint vb.) once karar versin, biz son durumu gorelim
    @EventHandler(priority = EventPriority.LOWEST)
    public void onSend(PacketEvent.Send e) {
        if (e.isCancelled()) return;
        Object p = e.getPacket();

        if (p instanceof ClientCommandC2SPacket c) {
            switch (c.getMode()) {
                case START_SPRINTING   -> { if (!core.sprint(true))  e.cancel(); }
                case STOP_SPRINTING    -> { if (!core.sprint(false)) e.cancel(); }
                case PRESS_SHIFT_KEY   -> { if (!core.sneak(true))   e.cancel(); }
                case RELEASE_SHIFT_KEY -> { if (!core.sneak(false))  e.cancel(); }
                default -> { }
            }
        } else if (p instanceof UpdateSelectedSlotC2SPacket s) {
            if (!core.slot(s.getSelectedSlot())) e.cancel();
        }
    }

    @EventHandler
    public void onReceive(PacketEvent.Receive e) {
        Object p = e.getPacket();
        if (p instanceof GameJoinS2CPacket || p instanceof PlayerRespawnS2CPacket) core.reset();
        else if (p instanceof UpdateSelectedSlotS2CPacket) core.serverChangedSlot();
    }
}
