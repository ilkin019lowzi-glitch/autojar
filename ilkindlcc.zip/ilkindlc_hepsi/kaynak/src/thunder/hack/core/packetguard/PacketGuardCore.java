package thunder.hack.core.packetguard;

/**
 * PacketGuardCore: giden paketlerde Grim BadPacketsA / F / G tipi "tekrar eden durum" bayraklarini onler.
 * Saf mantik, Minecraft tipi yok. Grim'in kendi izledigi duruma birebir uyar:
 *   A: HELD_ITEM_CHANGE, slot == lastSlot            -> bayrak
 *   F: START_SPRINTING iken lastSprinting == true     -> bayrak   |  STOP_SPRINTING iken lastSprinting == false -> bayrak
 *   G: PRESS_SHIFT   iken lastSneaking   == true      -> bayrak   |  RELEASE_SHIFT  iken lastSneaking   == false -> bayrak
 * Grim bu uc durumu yalniz kendisine ULASAN paketlerden gunceller, bu yuzden biz de yalniz gercekten gonderilen paketlerle guncelleriz.
 * Baslangic durumu (sprint=false, sneak=false, slot=bilinmiyor) Grim'in giriste varsaydigi durumdur.
 *
 * Her metot: true = paket gonderilsin, false = tekrar, IPTAL ET.  Durum yalniz true dondugunde ilerler.
 */
public final class PacketGuardCore {
    private boolean sprint = false;
    private boolean sneak = false;
    private int slot = -1;

    public int dropped = 0;

    /** Giriste, respawn'da, dunya degisiminde cagir. */
    public void reset() { sprint = false; sneak = false; slot = -1; }

    /** Sunucu slot'u zorla degistirdi (S2C). Bir sonraki slot paketi mutlaka gecsin. */
    public void serverChangedSlot() { slot = -1; }

    public boolean sprint(boolean start) {
        if (start == sprint) { dropped++; return false; }
        sprint = start; return true;
    }

    public boolean sneak(boolean press) {
        if (press == sneak) { dropped++; return false; }
        sneak = press; return true;
    }

    public boolean slot(int s) {
        if (s == slot) { dropped++; return false; }
        slot = s; return true;
    }

    public boolean sprintState() { return sprint; }
}
