package thunder.hack.features.hud.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import thunder.hack.core.Managers;
import thunder.hack.features.hud.HudElement;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.setting.Setting;
import thunder.hack.setting.impl.ColorSetting;
import thunder.hack.utility.render.Render2DEngine;

import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * ilkindlc watermark V3: "i" logo + name + FPS + ping + clock, optional flowing gradient text.
 * Register it wherever ilkindlcWatermarkV2 is registered (HUD module list).
 */
public class ilkindlcWatermarkV3 extends HudElement {
    public enum Style { Elite, Glass, Minimal }

    private static final Identifier LOGO = Identifier.of("thunderhack", "textures/gui/ilk/ilk_logo.png");
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final Setting<Style> style = new Setting<>("Style", Style.Elite);
    private final Setting<Boolean> logo = new Setting<>("Logo", true);
    private final Setting<Boolean> fps = new Setting<>("FPS", true);
    private final Setting<Boolean> ping = new Setting<>("Ping", true);
    private final Setting<Boolean> time = new Setting<>("Time", true);
    private final Setting<Boolean> flow = new Setting<>("Flowing Text", true);
    private final Setting<ColorSetting> color1 = new Setting<>("Color 1", new ColorSetting(new Color(124, 92, 255)));
    private final Setting<ColorSetting> color2 = new Setting<>("Color 2", new ColorSetting(new Color(64, 206, 255)));

    public ilkindlcWatermarkV3() {
        super("ilkindlcWatermarkV3", 120, 18);
    }

    @Override
    public void onRender2D(DrawContext context) {
        super.onRender2D(context);
        MatrixStack ms = context.getMatrices();

        List<String> parts = new ArrayList<>();
        if (fps.getValue()) parts.add("FPS " + mc.getCurrentFps());
        if (ping.getValue()) parts.add("PING " + Managers.SERVER.getPing() + "ms");
        if (time.getValue()) parts.add(LocalTime.now().format(CLOCK));

        final float h = 18f, pad = 6f, gap = 8f, logoSize = 11f;
        String name = "ilkindlc";
        float nameW = FontRenderers.sf_bold.getStringWidth(name);

        float w = pad + (logo.getValue() ? logoSize + 4f : 0f) + nameW;
        for (String p : parts) w += gap + 1f + gap + FontRenderers.sf_medium.getStringWidth(p);
        w += pad;

        float x = getPosX(), y = getPosY();
        setBounds(x, y, w, h);

        Color a = color1.getValue().getColorObject();
        Color b = color2.getValue().getColorObject();

        switch (style.getValue()) {
            case Elite -> {
                Render2DEngine.drawBlurredShadow(ms, x, y, w, h, 12, Render2DEngine.applyOpacity(a, 0.35f));
                Render2DEngine.drawRound(ms, x, y, w, h, 4f, new Color(14, 14, 20, 230));
                Render2DEngine.drawGradientRound(ms, x + 3f, y + h - 2f, w - 6f, 1.2f, 0.6f, a, b, b, a);
            }
            case Glass -> {
                Render2DEngine.drawBlurredShadow(ms, x, y, w, h, 14, Render2DEngine.applyOpacity(b, 0.25f));
                Render2DEngine.drawRound(ms, x, y, w, h, 7f, new Color(255, 255, 255, 28));
                Render2DEngine.drawRound(ms, x + 0.5f, y + 0.5f, w - 1f, h - 1f, 6.5f, new Color(10, 10, 16, 150));
            }
            case Minimal -> { }
        }

        float cx = x + pad;
        float ty = y + (h - FontRenderers.sf_bold.getStringHeight(name)) / 2f + 0.5f;

        if (logo.getValue()) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShaderTexture(0, LOGO);
            Render2DEngine.renderTexture(ms, cx, y + (h - logoSize) / 2f, logoSize, logoSize, 0, 0, 512, 512, 512, 512);
            cx += logoSize + 4f;
        }

        cx = drawText(ms, name, cx, ty, a, b, flow.getValue(), true);

        for (String p : parts) {
            cx += gap;
            Render2DEngine.drawRect(ms, cx, y + 5f, 1f, h - 10f, new Color(255, 255, 255, 40));
            cx += 1f + gap;
            FontRenderers.sf_medium.drawString(ms, p, cx, ty + 0.5f, new Color(210, 214, 230));
            cx += FontRenderers.sf_medium.getStringWidth(p);
        }
    }

    /** Draws text char by char; when flowing, the colour wave travels along the string over time. */
    private float drawText(MatrixStack ms, String text, float x, float y, Color a, Color b, boolean animated, boolean bold) {
        double t = System.currentTimeMillis() / 650.0;
        var font = bold ? FontRenderers.sf_bold : FontRenderers.sf_medium;
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            float k = animated ? (float) ((Math.sin(t - i * 0.45) + 1.0) / 2.0) : (float) i / Math.max(1, text.length() - 1);
            font.drawString(ms, ch, x, y, Render2DEngine.interpolateColorC(a, b, k));
            x += font.getStringWidth(ch);
        }
        return x;
    }
}
