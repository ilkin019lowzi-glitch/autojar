package thunder.hack.features.modules.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import thunder.hack.core.Managers;
import thunder.hack.features.modules.Module;
import thunder.hack.setting.Setting;

/**
 * TriggerBot: crosshair hitbox'in uzerine geldiginde vurur. Kritik acikken yalnizca gercek kritik
 * kosulu (dusuyor, yerde degil, kosmuyor, suda/merdivende/binekte degil, kor degil) ve cooldown hazir olunca vurur.
 * Aura'dan bagimsiz: nisani DEGISTIRMEZ, sadece oyuncunun kendi bakisini kullanir.
 *
 * DERLENMEDI, oyunda DENENMEDI. ModuleManager'a kaydedilmesi gerekir (kaynak yok, elle eklenecek).
 */
public class TriggerBot extends Module {
    private final Setting<Boolean> onlyCrit = new Setting<>("OnlyCrit", true);
    private final Setting<Float> cooldown = new Setting<>("Cooldown", 0.95f, 0.5f, 1.0f);
    private final Setting<Boolean> players = new Setting<>("Players", true);
    private final Setting<Boolean> mobs = new Setting<>("Mobs", true);
    private final Setting<Boolean> ignoreFriends = new Setting<>("IgnoreFriends", true);
    private final Setting<Boolean> pauseUsing = new Setting<>("PauseWhenUsing", true);

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @Override
    public void onUpdate() {
        if (fullNullCheck()) return;
        if (mc.currentScreen != null) return;
        if (pauseUsing.getValue() && mc.player.isUsingItem()) return;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult ehr)) return;
        Entity target = ehr.getEntity();

        if (!isValid(target)) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < cooldown.getValue()) return;
        if (onlyCrit.getValue() && !canCrit()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private boolean isValid(Entity e) {
        if (e == null || e == mc.player || !e.isAlive() || !e.isAttackable()) return false;
        if (!(e instanceof LivingEntity)) return false;
        if (e instanceof PlayerEntity p) {
            if (!players.getValue()) return false;
            return !(ignoreFriends.getValue() && Managers.FRIEND.isFriend(p));
        }
        return mobs.getValue();
    }

    /** Vanilla kritik kosulu (PlayerEntity#attack ile ayni). */
    private boolean canCrit() {
        var p = mc.player;
        return p.fallDistance > 0.0f
                && !p.isOnGround()
                && !p.isClimbing()
                && !p.isTouchingWater()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && !p.hasVehicle()
                && !p.isSprinting();
    }
}
