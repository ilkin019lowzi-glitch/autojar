package thunder.hack.gui.clickui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.utility.render.Render2DEngine;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

/** Cyan/purple UI animation helpers for ilkindlc. Call only from the render thread. */
public final class IlkAnimations {
    private static final long OPEN_DURATION_MS = 260L;
    private static final Map<String, Float> TOGGLE_PROGRESS = new HashMap<>();
    private static long openedAt;

    private IlkAnimations() {}

    /** Start/restart the ClickGUI pop-in animation. */
    public static void startClickGuiOpen() {
        openedAt = System.currentTimeMillis();
    }

    /** 0..1 eased progress, useful for staggered category/button entrances. */
    public static float openProgress() {
        if (openedAt == 0L) return 1f;
        float t = Math.min(1f, (System.currentTimeMillis() - openedAt) / (float) OPEN_DURATION_MS);
        return 1f - (float) Math.pow(1f - t, 3.0);
    }

    /**
     * Wrap the category rendering section with begin/end to scale the whole GUI
     * from its center. Always call endAnimatedContent() in a finally block.
     */
    public static void beginAnimatedContent(MatrixStack matrices, int width, int height) {
        float p = openProgress();
        float scale = 0.92f + 0.08f * p;
        matrices.push();
        matrices.translate(width / 2f, height / 2f, 0f);
        matrices.scale(scale, scale, 1f);
        matrices.translate(-width / 2f, -height / 2f, 0f);
    }

    public static void endAnimatedContent(MatrixStack matrices) {
        matrices.pop();
    }

    /** Draw an animated on/off pill beside a module setting. id must be stable per module. */
    public static void renderModuleToggle(DrawContext context, String id, float x, float y, boolean enabled) {
        if (id == null) return;
        float target = enabled ? 1f : 0f;
        float current = TOGGLE_PROGRESS.getOrDefault(id, target);
        current += (target - current) * 0.30f;
        if (Math.abs(target - current) < 0.01f) current = target;
        TOGGLE_PROGRESS.put(id, current);

        MatrixStack matrices = context.getMatrices();
        int r = (int) (35 + 35 * current);
        int g = (int) (38 + 145 * current);
        int b = (int) (52 + 190 * current);
        Render2DEngine.drawRound(matrices, x, y, 25f, 11f, 5.5f,
                new Color(r, g, b, 230));
        float knobX = x + 2f + 14f * current;
        Render2DEngine.drawRound(matrices, knobX, y + 2f, 7f, 7f, 3.5f,
                new Color(245, 248, 255, 255));
    }

    /** Small cyan/purple accent glow for a module row while it is enabled. */
    public static void renderModuleGlow(DrawContext context, float x, float y, float width, float height,
                                         boolean enabled) {
        if (!enabled) return;
        int alpha = 28 + (int) (16 * (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 240.0)));
        context.fill((int) x, (int) y, (int) (x + 2f), (int) (y + height), (alpha << 24) | 0x48B9FF);
        context.fill((int) x + 2, (int) y, (int) (x + width), (int) (y + 1f), 0x284B42D8);
    }
}
