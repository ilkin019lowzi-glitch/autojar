package thunder.hack.gui.clickui;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

/**
 * Lightweight cyan/purple cursor trail for ClickGUI.
 * Call update(mouseX, mouseY, nowMs) and render(context, nowMs) from the
 * ClickGUI render method. Coordinates must be scaled GUI coordinates.
 */
public final class IlkCursorTrail {
    private static final long LIFE_MS = 420L;
    private static final double MIN_DISTANCE_SQ = 3.0;
    private static final int MAX_POINTS = 24;
    private static final Deque<Point> POINTS = new ArrayDeque<>();
    private static double lastX = Double.NaN;
    private static double lastY = Double.NaN;

    private IlkCursorTrail() { }

    /** Add the current mouse position. Call once per rendered frame. */
    public static void update(double mouseX, double mouseY, long nowMs) {
        if (Double.isNaN(lastX) || distanceSq(mouseX, mouseY, lastX, lastY) >= MIN_DISTANCE_SQ) {
            POINTS.addLast(new Point(mouseX, mouseY, nowMs));
            lastX = mouseX;
            lastY = mouseY;
        }
        prune(nowMs);
    }

    /** Draw fading rounded-square particles behind the cursor. */
    public static void render(DrawContext context, long nowMs) {
        prune(nowMs);
        int index = 0;
        int count = POINTS.size();
        for (Point point : POINTS) {
            float age = Math.max(0f, Math.min(1f, (nowMs - point.time) / (float) LIFE_MS));
            float fade = 1f - age;
            float progress = count <= 1 ? 1f : index / (float) (count - 1);
            int alpha = Math.max(0, Math.min(150, (int) (fade * (35f + progress * 105f))));
            int size = Math.max(1, (int) (2f + progress * 3f));
            int rgb = progress < 0.55f ? 0x48B9FF : 0x8B5CFF;
            int color = (alpha << 24) | rgb;
            int x = (int) Math.round(point.x - size / 2.0);
            int y = (int) Math.round(point.y - size / 2.0);
            context.fill(x, y, x + size, y + size, color);
            index++;
        }
    }

    /** Clear trail when ClickGUI closes or changes screen. */
    public static void clear() {
        POINTS.clear();
        lastX = Double.NaN;
        lastY = Double.NaN;
    }

    private static void prune(long nowMs) {
        while (!POINTS.isEmpty() && (nowMs - POINTS.peekFirst().time > LIFE_MS || POINTS.size() > MAX_POINTS)) {
            POINTS.removeFirst();
        }
    }

    private static double distanceSq(double x1, double y1, double x2, double y2) {
        double dx = x1 - x2;
        double dy = y1 - y2;
        return dx * dx + dy * dy;
    }

    private static final class Point {
        private final double x;
        private final double y;
        private final long time;

        private Point(double x, double y, long time) {
            this.x = x;
            this.y = y;
            this.time = time;
        }
    }
}
