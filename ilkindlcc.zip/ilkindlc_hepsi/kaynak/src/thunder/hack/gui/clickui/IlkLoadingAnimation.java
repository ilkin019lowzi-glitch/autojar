package thunder.hack.gui.clickui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import thunder.hack.gui.font.FontRenderers;

/** Cyan/purple loading overlay. Call render() while a config or screen is loading. */
public final class IlkLoadingAnimation {
    private IlkLoadingAnimation() {}

    public static void render(DrawContext context, int width, int height, long timeMs, String message) {
        int cx = width / 2;
        int cy = height / 2;
        context.fill(0, 0, width, height, 0xB3070A12);

        // Soft animated halo.
        int pulse = 20 + (int) (13 * (0.5 + 0.5 * Math.sin(timeMs / 230.0)));
        context.fill(cx - 35, cy - 37, cx + 35, cy + 33, (pulse << 24) | 0x304F9B);

        double phase = (timeMs % 1050L) / 1050.0 * Math.PI * 2.0;
        for (int i = 0; i < 16; i++) {
            double a = phase - i * (Math.PI * 2.0 / 16.0);
            int x = cx + (int) Math.round(Math.cos(a) * 22.0);
            int y = cy - 15 + (int) Math.round(Math.sin(a) * 22.0);
            int alpha = 45 + (int) (210.0 * i / 15.0);
            int color = (alpha << 24) | (i < 8 ? 0x48B9FF : 0x936BFF);
            context.fill(x - 2, y - 2, x + 3, y + 3, color);
        }

        MatrixStack matrices = context.getMatrices();
        FontRenderers.sf_medium.drawCenteredString(matrices, "ILKINDLC", cx, cy + 20f, 0xFFEAF6FF);
        if (message != null && !message.isBlank())
            FontRenderers.sf_medium.drawCenteredString(matrices, message, cx, cy + 34f, 0xFF9FCBEB);

        // Animated thin progress-like accent (indeterminate; not a fake percentage).
        int barW = 74;
        int sweep = (int) ((timeMs / 7L) % (barW + 24)) - 12;
        context.fill(cx - barW / 2, cy + 47, cx + barW / 2, cy + 49, 0x553B5268);
        context.fill(cx + sweep - 5, cy + 47, cx + sweep + 5, cy + 49, 0xFF48B9FF);
    }
}
