package thunder.hack.gui.clickui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import thunder.hack.features.modules.Module;
import thunder.hack.features.modules.client.ClickGui;
import thunder.hack.core.manager.client.ModuleManager;
import thunder.hack.gui.clickui.impl.SearchBar;
import thunder.hack.gui.font.FontRenderers;
import thunder.hack.gui.thundergui.ThunderGui;
import thunder.hack.gui.mainmenu.MainMenuScreen;
import thunder.hack.utility.render.Render2DEngine;

import java.awt.Color;
import java.util.List;

/**
 * ClickGUI (P ile acilan menu) icin: asagi kaydirma + arama cubugu.
 *
 *  - Menu, ekrandan tasan kategorileri gormek icin asagi/yukari kayar:
 *      fare tekeri, ARROW UP / ARROW DOWN, PAGE UP / PAGE DOWN  (adim = 24 px)
 *  - Ust ortada arama kutusu var. Yazdikca modul adi icinde gecenler kalir,
 *    TUM kategorilerde ayni anda filtrelenir (eslesmeyen butonlar ekran disina atilir).
 *  - Menu kapatilip tekrar acilinca (init) her sey eski haline doner:
 *    kayma sifirlanir, kategoriler eski Y'sine gelir, arama temizlenir.
 *
 * ClickGUI ve Category'ye eklenen cagrilar icin: docs/CLICKGUI_PATCH.md ("IlkMenu baglantilari").
 */
public final class IlkMenu {
    private static final float STEP  = 24f;   // her kaydirma adimi
    private static final float BOX_W = 150f;  // arama kutusu genisligi
    private static final float BOX_H = 15f;   // arama kutusu yuksekligi
    private static final float BOX_Y = 2f;    // ekranin ustunden bosluk
    private static final float NAV_Y = 2f;
    private static final float NAV_H = 17f;

    private static float offset = 0f;         // simdiki kayma (0 = ilk hal)
    private static boolean focused = false;   // arama kutusuna tiklandi mi
    private static String query = "";         // aranan yazi
    private static int snapFrames = 0;        // kac kare daha anlik yerlesim uygulanacak

    private IlkMenu() {}

    // ---------------------------------------------------------------- acilis
    /** ClickGUI.init() sonunda cagrilir: menuyu eski haline dondurur. */
    public static void onInit() {
        IlkAnimations.startClickGuiOpen();
        shift(-offset);               // kategorileri eski Y'sine geri tasi
        offset = 0f;
        focused = false;
        setQuery("");
        if (ModuleManager.clickGui != null)
            ModuleManager.clickGui.scrollMode.setValue(ClickGui.scrollModeEn.Old); // eski ic-kaydirmayi kapat
        for (AbstractCategory c : ClickGUI.windows) {
            List<?> b = buttons(c);
            if (b != null) b.removeIf(o -> o instanceof SearchBar);  // eski arama cubugunu kaldir
        }
    }

    private static void setQuery(String q) {
        boolean changed = !q.equals(query);
        query = q;
        SearchBar.moduleName = q;
        SearchBar.listening = !q.isEmpty();
        if (changed) {
            // arama yapilirken menu asagi kaymis olabilir: eslesenler en uste gelsin
            if (!q.isEmpty() && offset > 0f) { shift(-offset); offset = 0f; }
            snapFrames = 40;  // butonlar animasyonla (hizlandirilmis) yerine kayar
        }
    }

    /**
     * Arama degisince eslesen butonlari ve kategori govdesini animasyonlu
     * ama hizli sekilde hedef konumuna oturtur (ust bosluk / alt bosluk kalmaz).
     * Category.render() sonundaki updatePosition() hedefleri (target_offset) zaten
     * sadece eslesenleri ust uste dizecek sekilde hesaplar; burada sadece
     * animasyonun yavas ilerlemesi atlanir.
     */
    private static void snapLayout() {
        for (AbstractCategory c : ClickGUI.windows) {
            List<?> b = buttons(c);
            if (b != null)
                for (Object o : b)
                    if (o instanceof AbstractButton ab && !hidden(ab))
                        ab.offsetY += (ab.target_offset - ab.offsetY) * 0.28f;   // yumusak + hizli kayma
            if (c instanceof Category cat && cat.isOpen())
                cat.catHeight += ((float) cat.getButtonsHeight() - cat.catHeight) * 0.28f;   // panel govdesi icerige gore, animasyonlu
        }
    }

    // -------------------------------------------------------------- kaydirma
    private static void shift(float dy) {
        if (dy == 0f) return;
        for (AbstractCategory c : ClickGUI.windows) c.setY(c.getY() - dy);
    }

    /** AbstractCategory'de public getter olmayan alanlar icin (buttons, catHeight). */
    private static Object field(Object o, String name) {
        try {
            java.lang.reflect.Field f = o.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.get(o);
        } catch (ReflectiveOperationException e) {
            return null;
        }
    }

    private static List<?> buttons(AbstractCategory c) {
        return field(c, "buttons") instanceof List<?> l ? l : null;
    }

    /** En fazla ne kadar kayabiliriz: en alttaki kategorinin dibi ekrana girene kadar. */
    private static float maxOffset() {
        float bottom = 0f;
        for (AbstractCategory c : ClickGUI.windows) {
            float h = 20f;
            if (c.isOpen() && field(c, "catHeight") instanceof Float f) h += f;
            bottom = Math.max(bottom, c.getY() + offset + h);   // offset eklenir = kaymasiz Y
        }
        int screenH = Module.mc.getWindow().getScaledHeight();
        return Math.max(0f, bottom - screenH + 40f);
    }

    private static void scrollBy(float d) {
        float n = Math.max(0f, Math.min(maxOffset(), offset + d));
        shift(n - offset);
        offset = n;
    }

    /** Fare tekeri: ClickGUI.mouseScrolled(...)'den cagrilir. */
    public static void scroll(double vertical) {
        scrollBy((float) -vertical * STEP);
    }

    // ----------------------------------------------------------------- arama
    /** Arama aktifken modul adinda sorgu gecmiyorsa buton gizlenir. */
    public static boolean hidden(AbstractButton b) {
        return !query.isEmpty()
                && b instanceof ModuleButton mb
                && !mb.module.getName().toLowerCase().contains(query.toLowerCase());
    }

    private static float boxX() {
        return Module.mc.getWindow().getScaledWidth() / 2f - 75f;
    }

    /** Fare tiklamasi. Arama kutusuna tiklandiysa true doner (menu baska bir sey yapmaz). */
    public static boolean click(double mx, double my, int button) {
        float bx = boxX();
        boolean in = mx >= bx && mx <= bx + BOX_W && my >= BOX_Y && my <= BOX_Y + BOX_H;
        focused = in;
        if (in && button == 1) setQuery("");        // sag tik = temizle

        float sw = Module.mc.getWindow().getScaledWidth();
        float cfgX = sw - 151f;
        float mainX = sw - 78f;
        if (mx >= cfgX && mx <= cfgX + 68f && my >= NAV_Y && my <= NAV_Y + NAV_H) {
            focused = false;
            ThunderGui.currentMode = ThunderGui.CurrentMode.CfgManager;
            Module.mc.setScreen(ThunderGui.getInstance());
            return true;
        }
        if (mx >= mainX && mx <= mainX + 68f && my >= NAV_Y && my <= NAV_Y + NAV_H) {
            focused = false;
            Module.mc.setScreen(MainMenuScreen.getInstance());
            return true;
        }
        return in;
    }

    /** Karakter girisi. Kutu aktifse yutar. */
    public static boolean type(char ch) {
        if (!focused) return false;
        if (ch >= 32 && ch != 127 && query.length() < 24) setQuery(query + ch);
        return true;
    }

    /** Tus basimi. true donerse menu tusu yutulur. */
    public static boolean key(int keyCode) {
        if (keyCode == 266 || keyCode == 265) { scrollBy(-STEP); return false; }  // PAGE_UP / UP
        if (keyCode == 267 || keyCode == 264) { scrollBy(STEP);  return false; }  // PAGE_DOWN / DOWN
        if (!focused) return false;
        if (keyCode == 256) { setQuery(""); focused = false; }                      // ESC: temizle + cik
        else if (keyCode == 257 || keyCode == 335) focused = false;                 // ENTER
        else if (keyCode == 259 && !query.isEmpty())                                // BACKSPACE
            setQuery(query.substring(0, query.length() - 1));
        return true;
    }

    // ------------------------------------------------------------------ cizim
    /** ClickGUI.render(...) sonunda cagrilir. */
    public static void render(DrawContext context, int mouseX, int mouseY) {
        if (offset > 0f) scrollBy(0f);              // pencere boyu degistiyse sinirla

        if (snapFrames > 0) { snapFrames--; snapLayout(); }

        // eslesmeyen butonlari ekran disina at (tum kategorilerde)
        for (AbstractCategory c : ClickGUI.windows) {
            List<?> b = buttons(c);
            if (b == null) continue;
            for (Object o : b)
                if (o instanceof AbstractButton ab && hidden(ab)) ab.y = -10000f;
        }

        MatrixStack ms = context.getMatrices();
        float bx = boxX();
        Render2DEngine.drawRound(ms, bx - 1f, 1f, BOX_W + 2f, 17f, 4f,
                focused ? new Color(255, 60, 60, 255) : new Color(170, 40, 40, 255));   // cerceve
        Render2DEngine.drawRound(ms, bx, 2f, BOX_W, BOX_H, 3.5f, new Color(20, 16, 24, 255)); // ic

        String caret = focused && (System.currentTimeMillis() / 500L) % 2L == 0L ? "_" : "";
        boolean placeholder = query.isEmpty() && !focused;
        FontRenderers.sf_medium.drawString(ms, placeholder ? "Ara..." : query + caret,
                bx + 6f, 7.0, placeholder ? 0xFF999999 : 0xFFFFFFFF);

        float sw = Module.mc.getWindow().getScaledWidth();
        float cfgX = sw - 151f;
        float mainX = sw - 78f;
        boolean cfgHover = mouseX >= cfgX && mouseX <= cfgX + 68f && mouseY >= NAV_Y && mouseY <= NAV_Y + NAV_H;
        boolean mainHover = mouseX >= mainX && mouseX <= mainX + 68f && mouseY >= NAV_Y && mouseY <= NAV_Y + NAV_H;
        Render2DEngine.drawRound(ms, cfgX, NAV_Y, 68f, NAV_H, 4f,
                cfgHover ? new Color(40, 145, 190, 245) : new Color(32, 105, 145, 225));
        Render2DEngine.drawRound(ms, mainX, NAV_Y, 68f, NAV_H, 4f,
                mainHover ? new Color(180, 70, 95, 245) : new Color(125, 45, 70, 225));
        FontRenderers.sf_medium.drawCenteredString(ms, "CONFIGS", cfgX + 34f, 7.0, 0xFFFFFFFF);
        FontRenderers.sf_medium.drawCenteredString(ms, "MAIN", mainX + 34f, 7.0, 0xFFFFFFFF);
    }
}
