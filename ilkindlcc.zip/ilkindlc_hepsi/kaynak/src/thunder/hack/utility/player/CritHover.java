package thunder.hack.utility.player;

import java.util.Random;

/**
 * CritHover v2: Aura icin "kritik bekleme" nisan noktasi uretici. Saf matematik, MC tipi yok. Birim: blok (1 cm = 0.01).
 *
 *  FAR    : menzil disi  -> imlec HER ZAMAN hitbox DISINDA, hizli hizli farkli noktalara gider, hic bir yere kilitlenmez.
 *  IDLE   : menzilde, kritik/cooldown dolmamis (elytra degil)
 *           -> vurustan hemen sonra imlec hitbox disina cikar, sonra hizli hizli rastgele noktalar arasinda gezer
 *              (bazen icerde, bazen disarda), durmaz, ayni yere iki kez ust uste gitmez.
 *  STRIKE : menzilde ve (hazir || donus suresi doldu || elytra)
 *           -> hitbox kenarindan 1-2 cm iceride, imlecin baktigi yone en yakin nokta.
 *
 * Vurus garantisi: STRIKE'a gecis "hazir olmasina kalan tick <= gereken donus tick + leadTicks" kosuluyla yapilir.
 * Gereken donus tick'i, imlecin acisal uzakligi / Aura'nin tick basi donus hizi (turnPerTick) ile hesaplanir.
 */
public final class CritHover {

    public enum Phase { STRIKE, IDLE, FAR, OUT }

    public double edgeMin = 0.010, edgeMax = 0.020;   // kenardan 1-2 cm iceride
    public double idleOut = 0.12;                     // IDLE: disari tasma payi
    public double farOut = 0.40;                      // FAR : hitbox'tan en fazla bu kadar uzak
    public double farMin = 0.06;                      // FAR : hitbox'tan en az bu kadar uzak (hep disarda)
    public int leadTicks = 1;                         // hesaplanan donus suresine eklenen emniyet
    public int wanderMinTicks = 2, wanderMaxTicks = 5; // hizli gezinme
    public double idleLerp = 0.45, farLerp = 0.35;
    public double microJitter = 0.004;
    public double minHop = 0.12;
    public double deepChance = 0.30;                  // vurusun %30'unda kenardan daha derin (5-14 cm) nokta
    public double deepMin = 0.05, deepMax = 0.14;
    public int holdMaxTicks = 4;                      // hazir olduktan sonra 0..N tick rastgele bekle (vurus araligi jitter'i)
    public double elytraWander = 0.04;                // elytra STRIKE'ta kutu icinde gezinme genisligi (kilitlenmeyi onler)
    public double outMin = 0.010, outMax = 0.020;     // ELYTRA OUT: hitbox'in 1-2 cm DISINA kilitlen
    public double maxTurnCap = 35.0;                  // elytra icin tick basi donus ust siniri (ElytraCombatRate: 40)                      // yeni hedef onceki hedeften en az bu kadar uzak olsun

    private final Random rng = new Random();
    private int targetId = Integer.MIN_VALUE;
    private double inset = 0.015;
    private final double[] cur = new double[3], dst = new double[3];
    private boolean haveCur = false, exitNext = false;
    private int holdTicks = 0, readyCount = 0, ttlTotal = 1;
    private boolean exitHop = false;
    private double outset = 0.015;
    private int ttl = 0;
    private double phase = 0;
    private Phase lastPhase = Phase.FAR;

    public Phase getPhase() { return lastPhase; }
    public void reset() { targetId = Integer.MIN_VALUE; haveCur = false; ttl = 0; exitNext = false; }

    /** Her vurustan sonra cagir: yeni kenar payi secer ve imleci hemen hitbox disina cikarir. */
    public void onHit() {
        inset = rng.nextDouble() < deepChance
                ? deepMin + rng.nextDouble() * (deepMax - deepMin)
                : edgeMin + rng.nextDouble() * (edgeMax - edgeMin);
        outset = outMin + rng.nextDouble() * (outMax - outMin);
        holdTicks = holdMaxTicks <= 0 ? 0 : rng.nextInt(holdMaxTicks + 1);
        readyCount = 0;
        ttl = 0;
        exitNext = true;
    }

    /**
     * Aura'nin saldiri kapisina ekle: hazir olduktan sonra holdTicks tick bekletir.
     * Boylece vurus araliklari (ms) arasindaki sapma buyur, TimingConsistency tipi kontroller sabit ritim gormez.
     */
    public boolean attackAllowed(boolean ready) {
        if (!ready) { readyCount = 0; return false; }
        return ++readyCount > holdTicks;
    }

    /** Elytra'da donus hizi ust siniri; Aura'nin step ayarlarina bu degeri uygula. */
    public double turnLimit(boolean elytra, double auraTurn) {
        return elytra ? Math.min(auraTurn, maxTurnCap) : auraTurn;
    }

    public static int ticksToCrit(double fallDistance, double vy, double threshold, boolean onGround) {
        if (fallDistance > threshold) return 0;
        if (onGround || vy >= -0.01) return -1;
        double speed = Math.max(0.08, -vy);
        return (int) Math.ceil((threshold - fallDistance) / speed);
    }

    /**
     * @param turnPerTick Aura'nin tick basina gercek donus hizi (derece). Bilinmiyorsa 30 ver.
     */
    public double[] aim(int id, double[] min, double[] max, double[] eye, double[] look,
                        boolean ready, int ticksToReady, boolean inRange, boolean elytra, double turnPerTick) {

        if (id != targetId) { targetId = id; haveCur = false; ttl = 0; exitNext = false; onHit(); exitNext = false; }

        double[] c = { (min[0]+max[0])/2, (min[1]+max[1])/2, (min[2]+max[2])/2 };
        double t = (c[0]-eye[0])*look[0] + (c[1]-eye[1])*look[1] + (c[2]-eye[2])*look[2];
        if (t < 0.5) t = 0.5;
        double[] p = { eye[0]+look[0]*t, eye[1]+look[1]*t, eye[2]+look[2]*t };

        if (!haveCur) { System.arraycopy(p, 0, cur, 0, 3); System.arraycopy(p, 0, dst, 0, 3); haveCur = true; }
        phase += 0.5 + rng.nextDouble() * 0.2;

        // strike noktasi: imlece en yakin, kenardan inset kadar iceride
        double[] s = new double[3];
        for (int i = 0; i < 3; i++) {
            double lo = min[i] + inset, hi = max[i] - inset;
            if (lo > hi) lo = hi = (min[i] + max[i]) / 2;
            double amp = elytra ? elytraWander : microJitter;
            double w = Math.sin(phase + i * 2.1) * amp + Math.sin(phase * 0.37 + i * 1.3) * amp * 0.8;
            s[i] = clamp(p[i] + w, lo, hi);
        }

        if (inRange) {
            // gereken donus suresi: imlecin su anki yonu -> strike noktasi
            double[] d = { s[0]-eye[0], s[1]-eye[1], s[2]-eye[2] };
            double dl = Math.sqrt(d[0]*d[0] + d[1]*d[1] + d[2]*d[2]);
            double dot = (d[0]*look[0] + d[1]*look[1] + d[2]*look[2]) / Math.max(dl, 1e-6);
            double ang = Math.toDegrees(Math.acos(clamp(dot, -1, 1)));
            // IDLE'daki uzak nokta icin cur'dan hesapla (imlec fiilen orada)
            double[] d2 = { cur[0]-eye[0], cur[1]-eye[1], cur[2]-eye[2] };
            double dl2 = Math.sqrt(d2[0]*d2[0] + d2[1]*d2[1] + d2[2]*d2[2]);
            double dot2 = (d2[0]*d[0] + d2[1]*d[1] + d2[2]*d[2]) / Math.max(dl2 * dl, 1e-6);
            double ang2 = Math.toDegrees(Math.acos(clamp(dot2, -1, 1)));
            double need = Math.ceil(Math.max(ang, ang2) / Math.max(turnPerTick, 1.0)) + leadTicks;

            boolean soon = ticksToReady >= 0 && ticksToReady <= need;
            if (ready || soon) {
                lastPhase = Phase.STRIKE;
                System.arraycopy(s, 0, cur, 0, 3);
                return s;
            }
        }

        if (elytra) {
            // ELYTRA: hazir degilken (menzil disi ya da vurustan hemen sonra) hitbox'in 1-2 cm DISINA kilitli kal.
            // Imlecin su anki bakisina en yakin dis nokta; hedef hareket ettikce takip eder, gezinmez.
            lastPhase = Phase.OUT;
            double[] o = new double[3];
            for (int i = 0; i < 3; i++) {
                double v = clamp(p[i], min[i] - outset, max[i] + outset);
                o[i] = v + Math.sin(phase * 0.8 + i * 1.9) * 0.0015;
            }
            pushOut(o, min, max, outset);
            System.arraycopy(o, 0, cur, 0, 3);
            return o;
        }

        lastPhase = inRange ? Phase.IDLE : Phase.FAR;
        if (--ttl <= 0) {
            ttl = wanderMinTicks + rng.nextInt(Math.max(1, wanderMaxTicks - wanderMinTicks + 1));
            ttlTotal = ttl;
            pickTarget(min, max, inRange);
        }
        // yavas basla, ortada hizlan, hedefe yaklasirken yavasla (insan eli)
        double prog = 1.0 - (double) ttl / Math.max(1, ttlTotal);
        double ease = 0.35 + 1.1 * Math.sin(Math.PI * Math.min(1.0, prog + 0.1));
        double lerp = Math.min(0.8, (inRange ? idleLerp : farLerp) * ease);
        if (exitHop) lerp = Math.max(lerp, 0.6);
        double[] r = new double[3];
        for (int i = 0; i < 3; i++) {
            cur[i] += (dst[i] - cur[i]) * lerp;
            r[i] = cur[i] + Math.sin(phase * 0.9 + i * 1.7) * 0.006;
        }
        if (!inRange) pushOut(r, min, max, farMin);   // FAR: gezinirken bile asla hitbox icine girmez
        return r;
    }

    private void pickTarget(double[] min, double[] max, boolean inRange) {
        double[] prev = dst.clone();
        for (int tries = 0; tries < 6; tries++) {
            boolean outside = !inRange || exitNext || rng.nextDouble() < 0.45;
            if (outside) {
                double lo = inRange ? 0.03 : farMin, hi = inRange ? idleOut : farOut;
                for (int i = 0; i < 3; i++) dst[i] = (min[i] - hi) + rng.nextDouble() * (max[i] - min[i] + 2 * hi);
                int axis = rng.nextInt(3);
                double over = lo + rng.nextDouble() * Math.max(0.0, hi - lo);
                if (exitNext) over = Math.max(over, 0.07);
                dst[axis] = rng.nextBoolean() ? max[axis] + over : min[axis] - over;
            } else {
                for (int i = 0; i < 3; i++) {
                    double l = min[i] + inset, h = max[i] - inset;
                    if (l > h) l = h = (min[i] + max[i]) / 2;
                    double u = (i == 1) ? 0.25 + 0.65 * (rng.nextDouble() + rng.nextDouble()) / 2 : rng.nextDouble();
                    dst[i] = l + u * (h - l);
                }
            }
            // %25 ihtimalle hedefi biraz asar (overshoot), sonraki hedefte geri doner
            if (rng.nextDouble() < 0.25) {
                for (int i = 0; i < 3; i++) dst[i] += (dst[i] - cur[i]) * 0.08;
            }
            double dx = dst[0]-prev[0], dy = dst[1]-prev[1], dz = dst[2]-prev[2];
            if (Math.sqrt(dx*dx + dy*dy + dz*dz) >= minHop) break;
        }
        exitHop = exitNext;
        exitNext = false;
    }

    /** Nokta kutunun icindeyse en yakin yuzden margin kadar disari iter. */
    private static void pushOut(double[] r, double[] min, double[] max, double margin) {
        boolean in = true;
        for (int i = 0; i < 3; i++) if (r[i] < min[i] - margin || r[i] > max[i] + margin) { in = false; break; }
        if (!in) return;
        int best = 0; double bd = 9, sign = 1;
        for (int i = 0; i < 3; i++) {
            double a = r[i] - (min[i] - margin), b = (max[i] + margin) - r[i];
            if (a < bd) { bd = a; best = i; sign = -1; }
            if (b < bd) { bd = b; best = i; sign = 1; }
        }
        r[best] = sign < 0 ? min[best] - margin - 1e-3 : max[best] + margin + 1e-3;
    }

    private static double clamp(double v, double lo, double hi) { return v < lo ? lo : Math.min(v, hi); }
}
