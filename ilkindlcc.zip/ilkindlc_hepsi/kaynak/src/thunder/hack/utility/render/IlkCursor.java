package thunder.hack.utility.render;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;

/**
 * ilkindlc text cursor for the ClickGUI search bar: a thin I-beam with a small accent dot (the "i" tittle).
 * Built procedurally, no asset needed. Call apply(window) while hovering, reset(window) when leaving.
 */
public final class IlkCursor {
    private static long cursor = 0L;
    private static final int S = 32;

    private IlkCursor() { }

    public static void apply(long window) {
        if (cursor == 0L) cursor = create();
        if (cursor != 0L) GLFW.glfwSetCursor(window, cursor);
    }

    public static void reset(long window) {
        GLFW.glfwSetCursor(window, 0L);
    }

    private static long create() {
        ByteBuffer px = MemoryUtil.memAlloc(S * S * 4);
        for (int y = 0; y < S; y++) {
            for (int x = 0; x < S; x++) {
                int r = 0, g = 0, b = 0, a = 0;
                boolean stem = x >= 15 && x <= 16 && y >= 5 && y <= 26;
                boolean topSerif = y >= 5 && y <= 6 && x >= 11 && x <= 20;
                boolean botSerif = y >= 25 && y <= 26 && x >= 11 && x <= 20;
                boolean dot = (x - 16) * (x - 16) + (y - 2) * (y - 2) <= 3;
                if (stem || topSerif || botSerif) { r = 255; g = 255; b = 255; a = 255; }
                if (dot) { r = 124; g = 92; b = 255; a = 255; }
                px.put((byte) r).put((byte) g).put((byte) b).put((byte) a);
            }
        }
        px.flip();
        GLFWImage img = GLFWImage.malloc();
        img.set(S, S, px);
        long c = GLFW.glfwCreateCursor(img, 15, 16);
        img.free();
        MemoryUtil.memFree(px);
        return c;
    }
}
