package thunder.hack.utility.sound;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.util.Identifier;

/** ilkindlc voice-event helpers. Call these only after the corresponding action succeeds. */
public final class IlkSound {
    private static final long KILL_COOLDOWN_MS = 1800L;
    private static long lastKillSoundMs;
    private static boolean welcomePlayed;

    private IlkSound() {}

    private static void play(String eventPath) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getSoundManager() == null) return;
        client.getSoundManager().play(PositionedSoundInstance.master(
                Identifier.of("minecraft", "ilkindlc." + eventPath), 1.0f));
    }

    /** Call once after the client has reached its first usable title/game screen. */
    public static void welcomeOnce() {
        if (welcomePlayed) return;
        welcomePlayed = true;
        play("welcome");
    }

    /** Call only after a config has been successfully written to disk. */
    public static void configCreated() { play("config_created"); }

    /** Call only after a config has been successfully loaded. */
    public static void configSelected() { play("config_selected"); }

    /** Call only for a confirmed player kill; suppresses repeated event callbacks. */
    public static void confirmedKill() {
        long now = System.currentTimeMillis();
        if (now - lastKillSoundMs < KILL_COOLDOWN_MS) return;
        lastKillSoundMs = now;
        play("gg");
    }
}
