import net.minecraft.*; import thunder.hack.features.modules.Module; import thunder.hack.features.modules.combat.Aura;
import thunder.hack.utility.player.CritHoverBridge;

public class BridgeTest {
  static int fail = 0;
  static void check(String n, boolean ok, String i){ System.out.println((ok?"PASS  ":"FAIL  ")+n+"  "+i); if(!ok) fail++; }
  static boolean inside(class_243 p, class_238 b){ return p.field_1352>=b.field_1323&&p.field_1352<=b.field_1320&&p.field_1351>=b.field_1322&&p.field_1351<=b.field_1325&&p.field_1350>=b.field_1321&&p.field_1350<=b.field_1324; }
  public static void main(String[] a){
    Aura au = new Aura(); class_746 pl = Module.mc.field_1724;
    class_1297 t = new class_1297(); class_238 b = t.method_5829();
    b.field_1323=-0.3; b.field_1322=0; b.field_1321=-0.3; b.field_1320=0.3; b.field_1325=1.8; b.field_1324=0.3;
    pl.eye = new class_243(3, 1.62, 0); au.rotationYaw = 90f; au.rotationPitch = 3f;   // +x'ten -x'e bakiyor
    class_243 orig = new class_243(9,9,9);

    // 1) kapali -> orijinal ayni nesne
    au.critHover.v = false;
    check("kapali: orijinal doner", CritHoverBridge.point(au, t, orig, false) == orig && CritHoverBridge.gate(au, true) == true, "");
    au.critHover.v = true;

    // 2) hedef yok / oyuncu yok -> orijinal
    check("hedef null: orijinal", CritHoverBridge.point(au, null, orig, false) == orig, "");

    // 3) menzil disi -> hitbox DISINDA, hareketli
    au.crit = false; pl.dist = 6f; au.range = 3f; int inside = 0; class_243 prev = null; int same = 0;
    for (int i=0;i<300;i++){ class_243 p = CritHoverBridge.point(au,t,orig,false); if(inside(p,b)) inside++; if(prev!=null&&p.field_1352==prev.field_1352&&p.field_1351==prev.field_1351) same++; prev=p; }
    check("menzil disi: hitbox disinda", inside==0, "icerde="+inside+"/300");
    check("menzil disi: donmuyor", same==0, "ayni="+same);

    // 4) menzilde, kritik hazir -> hitbox icinde
    pl.dist = 2f; au.crit = true; int out = 0;
    for (int i=0;i<50;i++){ if(!inside(CritHoverBridge.point(au,t,orig,true),b)) out++; }
    check("menzilde+hazir: STRIKE icerde", out==0, "disarda="+out);

    // 5) menzilde, hazir degil, yerde -> gezinir (zaman zaman disarda)
    au.crit = false; pl.ground = true; out = 0;
    CritHoverBridge.hit(au);
    for (int i=0;i<400;i++){ if(!inside(CritHoverBridge.point(au,t,orig,false),b)) out++; }
    check("menzilde+bekleme: hitbox disina cikiyor", out>40 && out<360, "disarda="+out+"/400");

    // 6) gate: shouldAttack=false -> hep false; true -> 0..4 tick sonra true
    int maxWait = -1, minWait = 99;
    for (int c=0;c<200;c++){
      CritHoverBridge.hit(au); int w=0; boolean ok=false;
      for (int k=0;k<10;k++){ if(CritHoverBridge.gate(au,true)){ok=true;break;} w++; }
      if(!ok){ maxWait=99; break; } maxWait=Math.max(maxWait,w); minWait=Math.min(minWait,w);
    }
    check("gate: her vurus en gec 4 tick bekleyip izin verir", maxWait<=4 && minWait==0, "min="+minWait+" max="+maxWait);
    check("gate: shouldAttack=false -> false", CritHoverBridge.gate(au,false)==false, "");

    // 7) elytra: menzil disi -> 1-2 cm DISARIDA kilitli; menzilde+hazir degil -> disarida; hazir -> icerde; vurus sonrasi hemen disari
    pl.flying = true; au.crit = false; au.cd = 0.2f; int in7 = 0; double gmx = 0;
    pl.dist = 6f; au.range = 3f;
    class_243 lastp = orig;
    for (int i=0;i<60;i++){ lastp = CritHoverBridge.point(au,t,orig,false); if(inside(lastp,b)) in7++; }
    check("elytra menzil disi: hitbox disinda", in7==0, "icerde="+in7+"/60");
    pl.dist = 2f; in7 = 0;
    for (int i=0;i<60;i++){ if(inside(CritHoverBridge.point(au,t,orig,false),b)) in7++; }
    check("elytra menzilde, cooldown dolmadi: disarida", in7==0, "icerde="+in7+"/60");
    au.crit = true; au.cd = 1f; boolean ins = false;
    for (int i=0;i<5;i++){ class_243 q = CritHoverBridge.point(au,t,orig,false); ins = inside(q,b); }
    check("elytra hazir: icerde", ins, "");
    CritHoverBridge.hit(au); au.crit = false; au.cd = 0.1f;
    class_243 q1 = CritHoverBridge.point(au,t,orig,false);
    check("elytra vurustan sonra ilk tick'te disarida", !inside(q1,b), "");

    // 8) hata durumunda orijinal: bridge icinde exception -> orig
    Module.mc.field_1724 = null;
    check("oyuncu yok: orijinal", CritHoverBridge.point(au,t,orig,false)==orig, "");
    System.out.println(fail==0?"\nHEPSI GECTI":"\nBASARISIZ: "+fail); System.exit(fail==0?0:1);
  }
}
