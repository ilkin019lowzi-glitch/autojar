import thunder.hack.utility.player.CritHover;

public class CritHoverTest {
    static int fail = 0;
    static void check(String n, boolean ok, String i) { System.out.println((ok ? "PASS  " : "FAIL  ") + n + "  " + i); if (!ok) fail++; }
    static double gap(double[] p, double[] mn, double[] mx) {
        double s = 0; for (int i = 0; i < 3; i++) { double g = Math.max(Math.max(mn[i] - p[i], p[i] - mx[i]), 0); s += g * g; } return Math.sqrt(s); }
    static double[] lookAt(double[] eye, double[] to) { double[] ag = angles(eye, to); return dir(ag[0], ag[1]); }
    static boolean inside(double[] p, double[] mn, double[] mx, double m) {
        for (int i = 0; i < 3; i++) if (p[i] < mn[i] + m || p[i] > mx[i] - m) return false; return true; }
    static double[] dir(double yaw, double pitch) {
        double y = Math.toRadians(yaw), p = Math.toRadians(pitch);
        return new double[] { -Math.sin(y) * Math.cos(p), -Math.sin(p), Math.cos(y) * Math.cos(p) }; }
    static double[] angles(double[] eye, double[] to) {
        double dx = to[0]-eye[0], dy = to[1]-eye[1], dz = to[2]-eye[2];
        return new double[] { Math.toDegrees(Math.atan2(-dx, dz)), Math.toDegrees(-Math.atan2(dy, Math.hypot(dx, dz))) }; }
    static double wrap(double a) { a %= 360; if (a > 180) a -= 360; if (a < -180) a += 360; return a; }
    /** ray(eye, look) hitbox'i kesiyor mu (slab) */
    static boolean rayHits(double[] e, double[] d, double[] mn, double[] mx) {
        double t0 = 0, t1 = 100;
        for (int i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1e-9) { if (e[i] < mn[i] || e[i] > mx[i]) return false; continue; }
            double a = (mn[i]-e[i])/d[i], b = (mx[i]-e[i])/d[i];
            if (a > b) { double x = a; a = b; b = x; }
            t0 = Math.max(t0, a); t1 = Math.min(t1, b);
            if (t0 > t1) return false;
        }
        return true;
    }

    public static void main(String[] a) {
        double[] mn = { -0.3, 0.0, -0.3 }, mx = { 0.3, 1.8, 0.3 };
        double[] eye = { 3.0, 1.62, 0.0 };
        CritHover h = new CritHover();
        double[] mid = { 0, 0.9, 0 };
        int n = 800;

        // FAR: asla hitbox icine girmez, hizli hareket eder, donmaz, kilitlenmez
        h.reset();
        double[] prev = null; int inside = 0, frozen = 0; double moved = 0; int distinct = 0; double[] last = null;
        for (int k = 0; k < n; k++) {
            double[] lk = dir(angles(eye, mid)[0], angles(eye, mid)[1]);
            double[] s = h.aim(1, mn, mx, eye, lk, true, 0, false, false, 25);
            if (inside(s, mn, mx, 0)) inside++;
            if (prev != null) { double d = Math.sqrt(Math.pow(s[0]-prev[0],2)+Math.pow(s[1]-prev[1],2)+Math.pow(s[2]-prev[2],2)); moved += d; if (d < 1e-9) frozen++; }
            if (last == null || Math.sqrt(Math.pow(s[0]-last[0],2)+Math.pow(s[1]-last[1],2)+Math.pow(s[2]-last[2],2)) > 0.15) { distinct++; last = s; }
            prev = s;
        }
        check("FAR hep hitbox DISINDA", inside == 0, "icerde=" + inside + "/" + n);
        check("FAR faz", h.getPhase() == CritHover.Phase.FAR, "" + h.getPhase());
        check("FAR hizli (tick basi ort. hareket > 2 cm)", moved / n > 0.02, String.format("ort=%.3f blok/tick", moved / n));
        check("FAR farkli noktalara gidiyor (kilitlenmiyor)", distinct > 40, "farkli nokta=" + distinct);
        check("FAR donmuyor", frozen == 0, "ayni=" + frozen);

        // IDLE: onHit sonrasi 3 tick icinde hitbox disina cikar; hizli; donmaz
        h.reset();
        for (int k = 0; k < 20; k++) h.aim(2, mn, mx, eye, dir(angles(eye, mid)[0], angles(eye, mid)[1]), false, -1, true, false, 25);
        int exitedWithin = -1;
        h.onHit();
        for (int k = 0; k < 6; k++) {
            double[] s = h.aim(2, mn, mx, eye, dir(angles(eye, mid)[0], angles(eye, mid)[1]), false, -1, true, false, 25);
            if (!inside(s, mn, mx, 0) && exitedWithin < 0) exitedWithin = k + 1;
        }
        check("IDLE vurustan sonra 6 tick icinde disari cikar", exitedWithin > 0, "tick=" + exitedWithin);
        prev = null; int out = 0; frozen = 0; moved = 0; distinct = 0; last = null;
        for (int k = 0; k < n; k++) {
            double[] s = h.aim(2, mn, mx, eye, dir(angles(eye, mid)[0], angles(eye, mid)[1]), false, -1, true, false, 25);
            if (!inside(s, mn, mx, 0)) out++;
            if (prev != null) { double d = Math.sqrt(Math.pow(s[0]-prev[0],2)+Math.pow(s[1]-prev[1],2)+Math.pow(s[2]-prev[2],2)); moved += d; if (d < 1e-9) frozen++; }
            if (last == null || Math.sqrt(Math.pow(s[0]-last[0],2)+Math.pow(s[1]-last[1],2)+Math.pow(s[2]-last[2],2)) > 0.12) { distinct++; last = s; }
            prev = s;
        }
        check("IDLE hem icerde hem disarda", out > 100 && out < n - 100, "disarda=" + out + "/" + n);
        check("IDLE hizli", moved / n > 0.015, String.format("ort=%.3f blok/tick", moved / n));
        check("IDLE farkli noktalar", distinct > 60, "farkli nokta=" + distinct);
        check("IDLE donmuyor", frozen == 0, "ayni=" + frozen);

        // VURUS GARANTISI + gecikme jitter'i: Aura donusu tick basi T derece ile sinirli.
        // Hazir olunca attackAllowed() izin verene kadar beklenir; vurus aninda fiili bakis hitbox'i kesmeli.
        for (double T : new double[] { 8, 12, 20, 35 }) {
            h.reset();
            double yaw = angles(eye, mid)[0], pitch = angles(eye, mid)[1];
            int cd = 12, missed = 0, hits = 0, cycles = 150;
            java.util.List<Integer> intervals = new java.util.ArrayList<>();
            int tick = 0, lastHit = -1;
            for (int cyc = 0; cyc < cycles; cyc++) {
                int k = cd;
                while (true) {                       // k = hazir olmasina kalan tick
                    boolean ready = (k <= 0);
                    double[] look = dir(yaw, pitch);
                    double[] s = h.aim(3, mn, mx, eye, look, ready, Math.max(k, 0), true, false, T);
                    double[] ag = angles(eye, s);
                    double dy = wrap(ag[0] - yaw), dp = ag[1] - pitch;
                    double m = Math.hypot(dy, dp);
                    if (m > T) { dy *= T / m; dp *= T / m; }
                    yaw += dy; pitch += dp;
                    tick++; k--;
                    if (h.attackAllowed(ready)) {
                        if (rayHits(eye, dir(yaw, pitch), mn, mx)) hits++; else missed++;
                        if (lastHit >= 0) intervals.add(tick - lastHit);
                        lastHit = tick;
                        break;
                    }
                }
                h.onHit();
            }
            double mean = 0; for (int v : intervals) mean += v; mean /= intervals.size();
            double var = 0; for (int v : intervals) var += (v - mean) * (v - mean); var /= intervals.size();
            double sdMs = Math.sqrt(var) * 50.0;
            check(String.format("VURUS garantisi, donus %.0f deg/tick", T), missed == 0, "tutan=" + hits + " kacan=" + missed);
            if (T == 20) check("VURUS ARALIGI std sapma > 50 ms (TimingConsistency esigi)", sdMs > 50.0, String.format("std=%.1f ms ort=%.1f tick", sdMs, mean));
        }

        // ---------------- ELYTRA ----------------
        // gap: noktanin hitbox'a en kisa uzakligi (icerdeyse 0)
        // 1) menzil disi: hitbox'in 1-2 cm DISINDA kilitli. Aura gibi donus hizi sinirli, hedef yavasca hareket ediyor.
        h.reset();
        int notOut = 0; double gmin = 9, gmax = 0, maxStep = 0; double[] prevP = null;
        double yawL = angles(eye, mid)[0], pitchL = angles(eye, mid)[1];
        for (int k = 0; k < 400; k++) {
            double ox = 0.8 * Math.sin(k * 0.05), oz = 0.8 * Math.cos(k * 0.04);             // hedef yavasca yuruyor
            double[] bmn = { mn[0] + ox, mn[1], mn[2] + oz }, bmx = { mx[0] + ox, mx[1], mx[2] + oz };
            double[] s2 = h.aim(20, bmn, bmx, eye, dir(yawL, pitchL), false, -1, false, true, 25);
            double[] ag = angles(eye, s2);
            double dy = wrap(ag[0] - yawL), dp = ag[1] - pitchL, m = Math.hypot(dy, dp);
            if (m > 25) { dy *= 25 / m; dp *= 25 / m; }
            yawL += dy; pitchL += dp;
            if (k < 30) { prevP = s2; continue; }                                            // ilk oturma suresi
            double g = gap(s2, bmn, bmx);
            if (g <= 0) notOut++; else { gmin = Math.min(gmin, g); gmax = Math.max(gmax, g); }
            if (prevP != null) maxStep = Math.max(maxStep, Math.sqrt(Math.pow(s2[0]-prevP[0],2)+Math.pow(s2[1]-prevP[1],2)+Math.pow(s2[2]-prevP[2],2)));
            prevP = s2;
        }
        check("ELYTRA menzil disi: hep hitbox DISINDA", notOut == 0 && h.getPhase() == CritHover.Phase.OUT, "icerde=" + notOut + " faz=" + h.getPhase());
        check("ELYTRA menzil disi: 1-2 cm disinda", gmin >= 0.0085 && gmax <= 0.0225, String.format("min=%.4f max=%.4f", gmin, gmax));
        check("ELYTRA menzil disi: kilitli (tick basi sicrama kucuk)", maxStep < 0.08, String.format("en buyuk adim=%.3f blok (hedef 0.04-0.05 blok/tick yuruyor)", maxStep));

        // 2) menzilde + hazir degil -> yine disarida; hazir -> icerde
        h.reset();
        double[] o1 = h.aim(21, mn, mx, eye, lookAt(eye, mid), false, 20, true, true, 30);
        check("ELYTRA menzilde, hazir degil: disarida", gap(o1, mn, mx) > 0 && h.getPhase() == CritHover.Phase.OUT, "faz=" + h.getPhase());
        double[] i1 = h.aim(21, mn, mx, eye, lookAt(eye, mid), true, 0, true, true, 30);
        check("ELYTRA menzilde, hazir: icerde (STRIKE)", gap(i1, mn, mx) == 0 && h.getPhase() == CritHover.Phase.STRIKE, "faz=" + h.getPhase());

        // 3) dongu: her vurustan sonra HEMEN disari, sonraki vurusta icerde. Donus hizi sinirli (35 deg/tick).
        for (double T : new double[] { 10, 20, 35 }) {
            h.reset();
            double yaw = angles(eye, mid)[0], pitch = angles(eye, mid)[1];
            int cd = 12, missed = 0, hits = 0, slowExit = 0, cycles = 120;
            for (int cyc = 0; cyc < cycles; cyc++) {
                int k = cd; boolean exitedFirstTick = false;
                while (true) {
                    boolean ready = k <= 0;
                    double[] s2 = h.aim(22, mn, mx, eye, dir(yaw, pitch), ready, Math.max(k, 0), true, true, T);
                    if (!ready && k == cd - 1 || (!ready && k == cd)) { /* vurustan sonraki ilk tick'ler */ }
                    if (k == cd && !ready) exitedFirstTick = gap(s2, mn, mx) > 0 || h.getPhase() == CritHover.Phase.OUT;
                    double[] ag = angles(eye, s2);
                    double dy = wrap(ag[0] - yaw), dp = ag[1] - pitch, m = Math.hypot(dy, dp);
                    if (m > T) { dy *= T / m; dp *= T / m; }
                    yaw += dy; pitch += dp; k--;
                    if (h.attackAllowed(ready)) { if (rayHits(eye, dir(yaw, pitch), mn, mx)) hits++; else missed++; break; }
                }
                h.onHit();
                if (!exitedFirstTick && cyc > 0) slowExit++;
            }
            check(String.format("ELYTRA dongu %.0f deg/tick: her vurus tuttu", T), missed == 0, "tutan=" + hits + " kacan=" + missed);
            if (T == 20) check("ELYTRA vurustan sonra ilk tick'te dis faz", slowExit == 0, "gec cikan=" + slowExit);
        }
        check("turnLimit elytra <= 35", h.turnLimit(true, 60) == 35.0 && h.turnLimit(false, 60) == 60.0, "");
        check("ticksToCrit", CritHover.ticksToCrit(0.05, -0.1, 0.2, false) == 2 && CritHover.ticksToCrit(0, 0, 0.2, true) == -1, "");
        System.out.println(fail == 0 ? "\nHEPSI GECTI" : "\nBASARISIZ: " + fail);
        System.exit(fail == 0 ? 0 : 1);
    }
}
