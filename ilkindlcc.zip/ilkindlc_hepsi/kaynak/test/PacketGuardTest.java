import thunder.hack.core.packetguard.PacketGuardCore;

public class PacketGuardTest {
    static int fail = 0;
    static void check(String n, boolean ok, String i) { System.out.println((ok ? "PASS  " : "FAIL  ") + n + "  " + i); if (!ok) fail++; }

    /** Grim BadPacketsF/G/A'nin birebir taklidi: duplicate gorursa flag sayar */
    static class GrimSim {
        boolean sprint = false, sneak = false; int slot = -1; int flagsF, flagsG, flagsA;
        void sprint(boolean start) { if (start == sprint) flagsF++; sprint = start; }
        void sneak(boolean press) { if (press == sneak) flagsG++; sneak = press; }
        void slot(int s) { if (s == slot) flagsA++; slot = s; }
    }

    public static void main(String[] a) {
        java.util.Random r = new java.util.Random(7);

        // 1) Aura'nin gercek bug'i: elle STOP + vanilla STOP, elle START + vanilla START
        PacketGuardCore g = new PacketGuardCore(); GrimSim grim = new GrimSim();
        g.sprint(true); grim.sprint(true);                 // oyuncu kosuyor
        for (int i = 0; i < 100; i++) {
            if (g.sprint(false)) grim.sprint(false);       // Aura.disableSprint paketi
            if (g.sprint(false)) grim.sprint(false);       // vanilla sendSprintingPacket ayni durumu yine yollar
            if (g.sprint(true))  grim.sprint(true);        // Aura.enableSprint
            if (g.sprint(true))  grim.sprint(true);        // vanilla tekrar
        }
        check("F: korumasiz akis flag uretirdi, korumali 0", grim.flagsF == 0 && g.dropped == 200, "flagF=" + grim.flagsF + " dusen=" + g.dropped);

        // 2) rastgele paket firtinasi: korumadan gecenler Grim'de 0 flag
        g = new PacketGuardCore(); grim = new GrimSim(); int sent = 0, total = 5000;
        for (int i = 0; i < total; i++) {
            switch (r.nextInt(3)) {
                case 0 -> { boolean v = r.nextBoolean(); if (g.sprint(v)) { grim.sprint(v); sent++; } }
                case 1 -> { boolean v = r.nextBoolean(); if (g.sneak(v))  { grim.sneak(v);  sent++; } }
                default -> { int s = r.nextInt(9);       if (g.slot(s))   { grim.slot(s);   sent++; } }
            }
        }
        check("Rastgele 5000 paket -> Grim A/F/G flag 0", grim.flagsA + grim.flagsF + grim.flagsG == 0,
              "A=" + grim.flagsA + " F=" + grim.flagsF + " G=" + grim.flagsG + " gecen=" + sent + " dusen=" + g.dropped);

        // 3) meşru degisim hic dusmez
        g = new PacketGuardCore();
        boolean ok = g.sprint(true) && g.sprint(false) && g.sprint(true) && g.sneak(true) && g.sneak(false) && g.slot(3) && g.slot(4) && g.slot(3);
        check("Mesru degisimler (A->B->A) gecer", ok && g.dropped == 0, "dusen=" + g.dropped);

        // 4) silent switch: slot X -> kilic -> X, arada tekrar yok
        g = new PacketGuardCore(); g.slot(2);
        boolean s1 = g.slot(5), s2 = g.slot(2);
        check("Silent switch gidis-donus gecer", s1 && s2, "");

        // 5) sunucu slot'u zorla degistirince sonraki paket gecer (desync olmaz)
        g = new PacketGuardCore(); g.slot(2); g.serverChangedSlot();
        check("S2C slot sonrasi ayni slot paketi gecer", g.slot(2), "");

        // 6) reset
        g = new PacketGuardCore(); g.sprint(true); g.sneak(true); g.slot(1); g.reset();
        check("reset: baslangic durumuna doner", g.sprint(true) && g.sneak(true) && g.slot(1), "");

        System.out.println(fail == 0 ? "\nHEPSI GECTI" : "\nBASARISIZ: " + fail);
        System.exit(fail == 0 ? 0 : 1);
    }
}
